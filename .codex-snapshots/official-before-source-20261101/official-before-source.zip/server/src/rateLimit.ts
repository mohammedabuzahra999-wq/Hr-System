import { getConnInfo } from '@hono/node-server/conninfo'
import type { Context, MiddlewareHandler } from 'hono'
import { HTTPException } from 'hono/http-exception'
import { isProduction } from './env.js'
import type { AppEnv } from './middleware.js'

/**
 * How often one caller may do something.
 *
 * This exists because the application is about to accept requests from people
 * who are not signed in — the careers page and the form on it — and an endpoint
 * open to the internet with no ceiling is an endpoint that can be used to
 * exhaust whatever is behind it.
 *
 * It also closes a hole that predates any of that. `POST /auth/login` had no
 * limit at all, so a script could try passwords indefinitely. Passwords here are
 * hashed with scrypt, which is deliberately slow, and that turns the same
 * opening into a second problem: fifty concurrent guesses saturate the CPU and
 * nobody else can sign in. One ceiling fixes both.
 *
 * ---
 *
 * The counters live in this process's memory. That is correct while the server
 * is one process and wrong the moment it is two: each instance would keep its
 * own tally and the real ceiling would multiply by the instance count. When this
 * is deployed behind more than one instance, the store below is what moves to
 * Redis — nothing else here changes.
 */

interface Window {
  count: number
  /** When the current window ends, in epoch ms. */
  resetAt: number
}

const buckets = new Map<string, Window>()

/**
 * Old windows are swept on a timer rather than on read.
 *
 * Sweeping on read only ever touches keys that come back, so a burst from ten
 * thousand addresses that never return would sit in the map forever. The timer
 * is unreferenced so it cannot hold the process open at shutdown.
 */
const SWEEP_MS = 5 * 60 * 1000
setInterval(() => {
  const now = Date.now()
  for (const [key, window] of buckets) if (window.resetAt <= now) buckets.delete(key)
}, SWEEP_MS).unref()

/**
 * Who is asking.
 *
 * Behind a proxy the socket address is the proxy's, so the forwarded header is
 * read first — but only its left-most entry, which is the one the edge appended.
 * A client can send any `X-Forwarded-For` it likes, so in development, where
 * there is no proxy to overwrite it, the header is ignored entirely; trusting it
 * there would let anyone reset their own counter by changing a header.
 */
function callerKey(c: Context): string {
  if (isProduction) {
    const forwarded = c.req.header('x-forwarded-for')
    const first = forwarded?.split(',')[0]?.trim()
    if (first) return first
  }

  // `callInternal()` dispatches an authenticated Request in memory. It has no
  // Node socket, so getConnInfo deliberately has nothing to inspect. Keep its
  // limiter bound to the already-authenticated person rather than throwing and
  // bypassing the Copilot route altogether.
  try {
    const address = getConnInfo(c)?.remote?.address
    if (address) return address
  } catch {
    const user = c.get('user') as { id?: unknown } | undefined
    if (typeof user?.id === 'string' && user.id) return `internal:${user.id}`
    return 'internal'
  }

  return 'unknown'
}

export interface RateLimitOptions {
  /** How many requests are allowed inside one window. */
  limit: number
  /** The window length, in milliseconds. */
  windowMs: number
  /** Distinguishes one limiter's counters from another's for the same caller. */
  name: string
  /**
   * Adds something from the request to the key — an email on a login attempt,
   * so guessing many passwords for one account is limited even when the attempt
   * comes from many addresses.
   */
  keyExtra?: (c: Context) => Promise<string | null> | string | null
}

export function rateLimit(options: RateLimitOptions): MiddlewareHandler<AppEnv> {
  return async (c, next) => {
    const extra = options.keyExtra ? await options.keyExtra(c) : null
    const key = `${options.name}:${callerKey(c)}${extra ? `:${extra}` : ''}`
    const now = Date.now()

    const existing = buckets.get(key)
    const window: Window =
      existing && existing.resetAt > now ? existing : { count: 0, resetAt: now + options.windowMs }
    window.count += 1
    buckets.set(key, window)

    const remaining = Math.max(0, options.limit - window.count)
    const retryAfter = Math.ceil((window.resetAt - now) / 1000)

    c.header('RateLimit-Limit', String(options.limit))
    c.header('RateLimit-Remaining', String(remaining))
    c.header('RateLimit-Reset', String(retryAfter))

    if (window.count > options.limit) {
      c.header('Retry-After', String(retryAfter))
      /**
       * 429 with a translatable code, and nothing about which limit was hit or
       * how many attempts remain. A response that counts down for the caller is
       * a response that tells a script exactly how to pace itself.
       */
      throw new HTTPException(429, { message: 'tooManyRequests' })
    }

    await next()
  }
}

/** Visible for tests and for a future move to a shared store. */
export function resetRateLimits(): void {
  buckets.clear()
}
