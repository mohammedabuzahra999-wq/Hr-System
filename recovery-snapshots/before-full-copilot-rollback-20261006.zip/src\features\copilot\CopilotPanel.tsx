import { Send, Sparkles, X } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { GapForm, type GapField } from './GapForm'
import type { ActionParams, CopilotAnswer } from '@hr/shared'
import { Alert } from '@/components/ui/Alert'
import { useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '@/features/auth/useAuth'
import { useI18n } from '@/features/i18n/useI18n'
import { ConfirmAction } from './ConfirmAction'
import { ReportView } from './ReportView'
import { api } from '@/lib/api'
import { errorText } from '@/lib/apiError'

/**
 * Asking the HR system a question.
 *
 * Open to every role, because what differs between them is not whether they may
 * ask but which questions exist — and the suggestion chips are fetched from the
 * server rather than listed here, so a role never sees an example of something
 * it would then be refused for asking.
 *
 * A refusal is written as a sentence about scope, not as an error. "Your role
 * does not cover that" is a fact about the system; "something went wrong"
 * implies a fault and invites retrying, which will not help.
 */

/**
 * What it is doing, while it does it.
 *
 * A report takes about twelve seconds — the model classifies, the server
 * queries, the model writes — and a single unchanging line for twelve seconds
 * reads as frozen. People stop waiting and conclude it cannot answer, which is
 * what happened.
 *
 * The three steps are the three things that actually happen, timed to roughly
 * when they do. It is a progress indication, not a fake one: nothing here claims
 * to know how far along the server is, and the wording stays true even if a step
 * runs long.
 */
function Thinking() {
  const { t } = useI18n()
  const [step, setStep] = useState(0)

  useEffect(() => {
    const timers = [
      window.setTimeout(() => setStep(1), 1800),
      window.setTimeout(() => setStep(2), 5000),
    ]
    return () => timers.forEach(window.clearTimeout)
  }, [])

  return (
    <div className="flex items-center gap-2.5 py-1">
      <span
        aria-hidden="true"
        className="size-4 shrink-0 rounded-full border-2 border-line border-t-brand motion-safe:animate-spin"
      />
      <div>
        <p className="text-sm text-ink">{t((['copilot.step1', 'copilot.step2', 'copilot.step3'] as const)[step]!)}</p>
        {step === 2 && <p className="text-xs text-muted">{t('copilot.slow')}</p>}
      </div>
    </div>
  )
}

const TONE: Record<string, string> = {
  good: 'bg-success',
  warning: 'bg-warning',
  bad: 'bg-danger',
  neutral: 'bg-muted',
}

export function CopilotPanel({
  onClose,
  floating = false,
  /**
   * Rendered as a page rather than as a card.
   *
   * Drops the border, the shadow and the close button — a page has no corner
   * to sit in and nothing to be dismissed back to — and gives the answer area
   * the height the screen can spare.
   */
  fullPage = false,
}: {
  onClose: () => void
  floating?: boolean
  fullPage?: boolean
}) {
  const { t, loc, dir, lang, setLang } = useI18n()
  const { logout } = useAuth()
  /**
   * Where the user is, sent with every question.
   *
   * "Explain this page" cannot be answered without it, and it lets the
   * suggestions be about the screen in front of them rather than a generic list.
   */
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const [question, setQuestion] = useState('')
  const [busy, setBusy] = useState(false)
  const [answer, setAnswer] = useState<CopilotAnswer | null>(null)
  const [asked, setAsked] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  /**
   * The boxes the server asked for, and what it already knows.
   *
   * Held with the action it belongs to, because submitting them does not send a
   * sentence — it names the instruction outright, which is why filling a form
   * needs no classification and cannot be misread.
   */
  const [gap, setGap] = useState<{
    action: string
    fields: GapField[]
    values: Record<string, string>
    /** Field name to the approved description a pre-filled value was taken from. */
    suggested: Record<string, string>
  } | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [pathname])

  async function ask(text: string) {
    const trimmed = text.trim()
    if (!trimmed || busy) return
    setBusy(true)
    setError(null)
    setAsked(trimmed)
    setAnswer(null)
    setGap(null)
    try {
      const d = await api.post<{
        answer: CopilotAnswer
        error?: string
        action?: string | null
        detail?: string | null
        missing?: { en: string; ar: string } | null
        optional?: boolean
        continuing?: boolean
        form?: GapField[]
        values?: Record<string, string>
        suggested?: Record<string, string>
      }>('/copilot/ask', { question: trimmed, path: pathname, lang })
      /*
        A refusal is only useful with the specifics attached: which names
        matched, or which piece was missing. Without them the person is left
        guessing at a phrasing, which is how an assistant earns a reputation
        for being temperamental.
      */
      /*
       * Boxes instead of a sentence about boxes.
       *
       * When the server sends fields, the wording that named the missing detail
       * is not shown: the labels say the same thing, in the place where it is
       * answered. Reading "I still need the job title" and then hunting for
       * where to put it was the complaint that produced this.
       */
      if (d.form?.length && d.action) {
        setGap({ action: d.action, fields: d.form, values: d.values ?? {}, suggested: d.suggested ?? {} })
        return
      }
      if (d.error) {
        setError(
          d.missing
            ? /*
                Two wordings, because there are two situations. "I still need X"
                is true of a leave request with no dates and false of a job
                description with no seniority — that one is worth asking about
                and not worth blocking on, and saying "I need it" would be the
                assistant misdescribing its own rules.
              */
              t(
                d.optional
                  ? 'copilot.err.action.wants'
                  : /*
                      "Almost" only means something to somebody who was already
                      part-way. On a first message it reads as a correction of a
                      sentence that was never wrong — they asked for a job
                      description and a job description needs a role, which is a
                      question, not a near miss.
                    */
                    d.continuing
                    ? 'copilot.err.action.needs'
                    : 'copilot.err.action.asks',
                { what: loc(d.missing) },
              )
            : [t(`copilot.err.${d.error}` as never), d.detail].filter(Boolean).join(' '),
        )
      }
      else setAnswer(d.answer)
    } catch (e) {
      setError(errorText(t, e))
    } finally {
      setBusy(false)
    }
  }

  /**
   * The boxes, filled in and sent.
   *
   * Goes to `/copilot/fill`, which names the action outright instead of
   * describing it, so there is no classification anywhere in the round trip —
   * measurably faster and, more to the point, incapable of being misread. What
   * comes back is the same proposal a sentence would have produced, so the
   * confirm step below is unchanged.
   */
  async function submitGap(values: Record<string, string>) {
    if (!gap || busy) return
    setBusy(true)
    setError(null)
    try {
      const d = await api.post<{
        answer: CopilotAnswer
        error?: string
        action?: string | null
        detail?: string | null
        missing?: { en: string; ar: string } | null
        optional?: boolean
        form?: GapField[]
        values?: Record<string, string>
      }>('/copilot/fill', { action: gap.action, values, question: asked ?? undefined })

      if (d.error) {
        /*
         * The boxes stay on screen holding what was typed. A form that emptied
         * itself to report a problem would make the person type it all again to
         * fix one field.
         */
        /* What they typed stays; a suggestion is only ever offered on the first pass. */
        if (d.form?.length) setGap({ action: gap.action, fields: d.form, values, suggested: {} })
        setError(
          d.missing
            ? t('copilot.err.action.needs', { what: loc(d.missing) })
            : [t(`copilot.err.${d.error}` as never), d.detail].filter(Boolean).join(' '),
        )
        return
      }
      setGap(null)
      setAnswer(d.answer)
    } catch (e) {
      setError(errorText(t, e))
    } finally {
      setBusy(false)
    }
  }

  /**
   * Committing a proposed action.
   *
   * Posts back the instruction the server resolved, unchanged. It is not a
   * token and grants nothing: the server re-checks the role and re-reads the
   * record, so this is a convenience that saves it remembering the proposal.
   */
  async function confirmAction(params: ActionParams) {
    /* Sent so the assistant can remember that this sentence, read this way, was right. */
    setBusy(true)
    setError(null)
    try {
      const d = await api.post<{ answer: CopilotAnswer }>('/copilot/do', { params, question: asked ?? undefined })
      setAnswer(d.answer)

      /*
        The one outcome the server cannot carry out itself. Switching language
        is this browser's preference, so the server says what should happen and
        this does it — after the answer is set, so the confirmation is already
        on screen when the interface flips around it.
      */
      const effect = d.answer.result.kind === 'done' ? d.answer.result.outcome.uiEffect : null
      if (effect?.kind === 'setLanguage') setLang(effect.language)
      /*
        The session is already gone server-side. Telling the app so is what
        turns this from "every page suddenly fails" into "you are signed out".
      */
      if (effect?.kind === 'signedOut') await logout()
      /* The confirmation was the press. Going there is the action, not an offer. */
      if (effect?.kind === 'navigate') {
        navigate(effect.path)
        onClose()
      }
    } catch (e) {
      setError(errorText(t, e))
    } finally {
      setBusy(false)
    }
  }

  /**
   * Backing out, and saying so.
   *
   * Somebody who reads a proposal and declines it has just told the assistant
   * it read them wrong — the clearest correction available, and the only one it
   * cannot work out for itself. Best-effort: a person cancelling must never be
   * shown an error for cancelling.
   */
  async function decline(action: string) {
    const question = asked
    setAnswer(null)
    setAsked(null)
    if (question) {
      await api.post('/copilot/declined', { question, action }).catch(() => undefined)
    }
  }

  const r = answer?.result
  // A report is a document; an answer is a card. They do not want the same width.
  const wide = r?.kind === 'report'


  return (
    <div
      className={`${
        // Docked under the topbar button, or placed by the floating launcher.
        /*
          Whole class names, never built from a variable.
          Tailwind reads these files as text to decide what CSS to generate, so
          `w-[min(${x},…)]` produces a class that is never written — the panel
          silently rendered at its minimum width instead of the one it asked for.
        */
        floating
          ? wide
            ? 'w-[min(46rem,calc(100vw-2rem))]'
            : 'w-[min(28rem,calc(100vw-2rem))]'
          : wide
            ? /*
                A report is wider than the button it hangs from, so it is placed
                against the viewport rather than anchored to that button. Anchored,
                it grew off the side of the screen the moment a report replaced an
                answer — the extra width had nowhere to go.
              */
              'fixed end-4 top-16 w-[min(46rem,calc(100vw-2rem))]'
            : 'absolute end-0 top-full mt-2 w-[min(28rem,calc(100vw-2rem))]'
      /*
        This z-index orders the panel against the topbar's other children, and
        nothing beyond them: the topbar is `sticky z-20`, which makes it a
        stacking context, and no z-index in here can climb out of it. Where the
        panel sits relative to the sidebar is decided on the sidebar — see the
        note there.
      */
      } ${
        fullPage
          ? 'w-full'
          : 'z-40 overflow-hidden rounded-2xl border border-line bg-surface shadow-[0_18px_55px_rgba(var(--shadow-tint),0.18)]'
      }`}
      dir={dir}
    >
      <div
        className={`flex items-center justify-between gap-2 px-4 py-3 ${fullPage ? '' : 'border-b border-line'}`}
        hidden={fullPage}
      >
        <p className="inline-flex items-center gap-2 text-sm font-semibold text-ink">
          <Sparkles className="size-4 text-brand" aria-hidden="true" />
          {t('copilot.title')}
        </p>
        <button
          type="button"
          onClick={onClose}
          aria-label={t('common.close')}
          className="rounded-md p-1 text-muted transition hover:bg-neutral-soft hover:text-ink"
        >
          <X className="size-4" aria-hidden="true" />
        </button>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault()
          void ask(question)
        }}
        className="flex items-center gap-2 border-b border-line px-3 py-2.5"
      >
        <input
          ref={inputRef}
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder={t('copilot.placeholder')}
          maxLength={500}
          className="h-9 min-w-0 flex-1 rounded-md border border-line bg-paper px-3 text-sm text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/15"
        />
        <button
          type="submit"
          disabled={busy || !question.trim()}
          aria-label={t('copilot.send')}
          className="rounded-md bg-brand p-2 text-white transition hover:bg-brand-700 disabled:opacity-45"
        >
          <Send className="size-4" aria-hidden="true" />
        </button>
      </form>

      <div
        className={`${fullPage ? 'max-h-[calc(100dvh-24rem)]' : wide ? 'max-h-[34rem]' : 'max-h-[26rem]'} overflow-y-auto px-4 py-3`}
      >
        {/*
          No prompts on the page.

          A grid of example questions is a menu, and a menu turns "ask me
          anything" into "pick one of these" — which is exactly the impression
          the page exists to avoid. The small panel keeps them, because a
          popover has no room to explain itself and a hint earns its space
          there.
        */}
        {/*
          No suggestions, in either place.
          They were kept here on the reasoning that a popover has no room to
          explain itself and a hint earns its space — but a list of things to
          say is only useful before you know what to say, and it is in the way
          every time after that. The box and the question are the whole of it.
        */}
        {asked && (
          <p className="mb-3 rounded-lg bg-neutral-soft px-3 py-2 text-sm text-neutral-ink">
            <bdi>{asked}</bdi>
          </p>
        )}

        {busy && !gap && <Thinking />}
        {error && <Alert>{error}</Alert>}

        {gap && (
          <GapForm
            fields={gap.fields}
            initial={gap.values}
            suggested={gap.suggested}
            busy={busy}
            onSubmit={submitGap}
            onCancel={() => {
              setGap(null)
              setError(null)
            }}
          />
        )}

        {answer?.refusal && (
          <p className="text-sm leading-relaxed text-muted">{t(`copilot.refusal.${answer.refusal}` as never)}</p>
        )}

        {answer && !answer.refusal && (
          <div className="space-y-3">
            {answer.sentence.en || answer.sentence.ar ? (
              <p className="text-sm leading-relaxed text-ink">{loc(answer.sentence)}</p>
            ) : answer.sharingOff ? (
              /*
                Said, not left blank. An empty space where a sentence should be
                reads as a fault; this is a setting, and the figures are intact.
              */
              <p className="rounded-lg border border-line bg-paper px-3 py-2 text-xs leading-relaxed text-muted">
                {t('privacy.sharingOff')}
              </p>
            ) : null}

            {answer.periodLabel && <p className="text-xs text-muted">{loc(answer.periodLabel)}</p>}

            {/* A greeting's real answer is the list of questions, not the sentence above it. */}

            {r?.kind === 'stats' && (
              <div className="grid grid-cols-2 gap-2">
                {r.stats.map((s, i) => (
                  <div key={i} className="rounded-lg border border-line bg-paper px-3 py-2">
                    <p className="text-lg font-bold tabular-nums text-ink">{s.value}</p>
                    <p className="text-xs text-muted">{loc(s.label)}</p>
                    {s.detail && <p className="text-[11px] text-muted">{loc(s.detail)}</p>}
                  </div>
                ))}
              </div>
            )}

            {r?.kind === 'people' && (
              <ul className="space-y-1.5">
                {r.people.map((p, i) => (
                  <li key={i} className="flex items-center gap-2 rounded-lg border border-line bg-paper px-3 py-2">
                    <span className={`size-2 shrink-0 rounded-full ${TONE[p.tone] ?? TONE.neutral}`} aria-hidden="true" />
                    <span className="min-w-0 flex-1 truncate text-sm text-ink">
                      <bdi>{loc(p.name)}</bdi>
                    </span>
                    <span className="shrink-0 text-xs text-muted">{loc(p.detail)}</span>
                  </li>
                ))}
              </ul>
            )}

            {r?.kind === 'guide' && (
              <div className="space-y-3">
                {r.steps.length > 0 && (
                  <ol className="space-y-2">
                    {r.steps.map((step, i) => (
                      <li key={i} className="flex gap-2.5">
                        <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-brand-50 text-[11px] font-bold text-brand">
                          {i + 1}
                        </span>
                        <div className="min-w-0">
                          <p className="text-sm leading-relaxed text-ink">{loc(step.text)}</p>
                          {/*
                            A step that names a screen takes you there. Reading
                            "go to Recruitment" and then having to find it is the
                            part of a written guide that wastes the most time.
                          */}
                          {step.path && (
                            <button
                              type="button"
                              onClick={() => {
                                navigate(step.path!)
                                onClose()
                              }}
                              className="mt-0.5 inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline"
                            >
                              {t('copilot.takeMe')}
                              <span aria-hidden="true">{dir === 'rtl' ? '\u2190' : '\u2192'}</span>
                            </button>
                          )}
                        </div>
                      </li>
                    ))}
                  </ol>
                )}
                {r.links.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 border-t border-line pt-2">
                    {r.links.map((l, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          navigate(l.path)
                          onClose()
                        }}
                        className="rounded-md border border-line bg-paper px-2 py-1 text-xs text-ink transition hover:border-brand hover:text-brand"
                      >
                        {loc(l.label)}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/*
              Several records fit. Each option is a full proposal, rendered the
              same way a single one is — so choosing and confirming are the same
              gesture, and the details that tell them apart are already there.
            */}
            {r?.kind === 'choose' && (
              <div className="space-y-2">
                {r.choice.options.map((option, i) => (
                  <ConfirmAction
                    key={i}
                    proposal={option}
                    busy={busy}
                    onCancel={() => void decline(option.action)}
                    onConfirm={() => void confirmAction(option.params)}
                  />
                ))}
              </div>
            )}

            {r?.kind === 'confirm' && (
              <ConfirmAction
                proposal={r.proposal}
                busy={busy}
                onCancel={() => void decline(r.proposal.action)}
                onConfirm={() => void confirmAction(r.proposal.params)}
              />
            )}

            {r?.kind === 'done' && (
              <div
                className={`rounded-xl border px-3 py-2.5 text-sm ${
                  r.outcome.ok ? 'border-success/30 bg-success-soft text-ink' : 'border-danger/30 bg-danger-soft text-ink'
                }`}
              >
                {/*
                  The refusal the form would have given, where there is one.
                  Same rule, same sentence, wherever the person met it.
                */}
                <p className="font-medium">
                  {r.outcome.messageKey
                    ? t(r.outcome.messageKey as never, r.outcome.messageParams ?? undefined)
                    : loc(r.outcome.message)}
                </p>
                {r.outcome.ok && r.outcome.path && (
                  <button
                    type="button"
                    onClick={() => {
                      navigate(r.outcome.path!)
                      onClose()
                    }}
                    className="mt-1.5 text-xs font-semibold text-brand underline-offset-2 hover:underline"
                  >
                    {t('action.seeIt')}
                  </button>
                )}
              </div>
            )}

            {r?.kind === 'report' && <ReportView report={r.report} sharingOff={answer.sharingOff} />}

            {r?.kind === 'table' && (
              <div className="overflow-x-auto rounded-lg border border-line">
                <table className="w-full text-sm">
                  <thead className="bg-paper">
                    <tr>
                      {r.columns.map((col, i) => (
                        <th key={i} className="px-3 py-2 text-start text-xs font-semibold text-muted">
                          {loc(col)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {r.rows.map((row, i) => (
                      <tr key={i} className="border-t border-line">
                        {row.map((cell, j) => (
                          <td key={j} className="px-3 py-2 text-ink">
                            <bdi>{cell}</bdi>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/*
        Said where it is read, not only in the code. Somebody using this every
        day should know its boundary without having to discover it by being
        refused.
      */}
      {/*
        Kept, even on the simplified page: it says the answers come from this
        system and stop at what this person may see. That is a claim about
        scope worth making once, quietly.
      */}
      <p
        className={`text-[11px] leading-relaxed text-muted ${
          fullPage ? 'pt-3 text-center' : 'border-t border-line px-4 py-2.5'
        }`}
      >
        {t('copilot.scope')}
      </p>
    </div>
  )
}
