import { desc, eq, sql } from 'drizzle-orm'
import type { HrReport, ReportSection, SessionUser } from '@hr/shared'
import { db } from '../db/client.js'
import {
  attendanceDays,
  cvFiles,
  documents,
  leaveBalances,
  payslips,
  requests,
  salaryStructures,
  users,
} from '../db/schema.js'
import { and, count, gte, inArray, lte } from 'drizzle-orm'
import { resolvePeriod } from '../copilot/execute.js'

/**
 * One employee, in full, as a report.
 *
 * This is the question HR is actually asked on the telephone: how much leave is
 * left, was there absence this month, what are they paid, is a CV on file, is
 * anything waiting on them. Built as a report so it prints and files like every
 * other one rather than becoming a fourth way of showing things.
 *
 * Two things depend on who is asking, and both are decided here rather than
 * described to a model:
 *
 *  - A manager sees only their own reports. Anybody else comes back as *not
 *    found* — not "forbidden", which would confirm that the person exists and
 *    quietly turn this into a directory of the whole company.
 *  - A manager does not see pay. Those sections are absent rather than present
 *    and blanked, so there is nothing to uncover by looking closely.
 */

const L = (en: string, ar: string) => ({ en, ar })

export async function buildEmployeeFile(
  identifier: { employeeNumber: string | null; personName: string | null },
  actor: SessionUser,
  now = new Date(),
): Promise<Omit<HrReport, 'summary' | 'findings'> | null> {
  const number = identifier.employeeNumber?.trim().toLowerCase()
  const name = identifier.personName?.trim().toLowerCase()
  if (!number && !name) return null

  const matches = await db
    .select()
    .from(users)
    .where(
      number
        ? sql`lower(${users.employeeNumber}) = ${number}`
        : sql`lower(${users.fullNameEn}) like ${`%${name}%`} or lower(${users.fullNameAr}) like ${`%${name}%`}`,
    )
    .limit(2)

  /**
   * A name matching two people is not an answer.
   *
   * Picking the first would hand over the wrong person's file, and there is no
   * way for the reader to tell. Better to come back empty so they quote a number.
   */
  if (matches.length !== 1) return null
  const person = matches[0]!

  if (actor.role === 'manager' && person.managerId !== actor.id && person.id !== actor.id) return null

  const p = resolvePeriod('thisMonth', now)
  const sections: ReportSection[] = []

  const [manager] = person.managerId
    ? await db
        .select({ en: users.fullNameEn, ar: users.fullNameAr })
        .from(users)
        .where(eq(users.id, person.managerId))
    : []

  sections.push({
    kind: 'table',
    heading: L('Details', 'البيانات'),
    columns: [L('Field', 'الحقل'), L('Value', 'القيمة')],
    rows: [
      ['الرقم الوظيفي', person.employeeNumber],
      ['المسمّى الوظيفي', person.jobTitleAr || person.jobTitleEn],
      ['القسم', person.departmentAr || person.departmentEn],
      ['المدير المباشر', manager ? manager.ar || manager.en : '—'],
      ['تاريخ المباشرة', String(person.joinedOn)],
      ['البريد', person.email],
      ['الحالة', person.isActive ? 'مفعّل' : 'معطّل'],
    ],
    note: null,
  })

  const counts = await db
    .select({ status: attendanceDays.status, total: count() })
    .from(attendanceDays)
    .where(
      and(
        inArray(attendanceDays.userId, [person.id]),
        gte(attendanceDays.workDate, p.from),
        lte(attendanceDays.workDate, p.to),
      ),
    )
    .groupBy(attendanceDays.status)

  const by = new Map(counts.map((r) => [r.status, Number(r.total)]))
  const [balance] = await db.select().from(leaveBalances).where(eq(leaveBalances.userId, person.id)).limit(1)

  sections.push({
    kind: 'stats',
    heading: L('This month, and leave', 'هذا الشهر، والإجازات'),
    stats: [
      { label: L('Present', 'حضور'), value: String(by.get('present') ?? 0), detail: null },
      { label: L('Late', 'تأخير'), value: String(by.get('late') ?? 0), detail: null },
      { label: L('Absent', 'غياب'), value: String(by.get('absent') ?? 0), detail: null },
      {
        label: L('Annual leave left', 'رصيد الإجازة السنوية'),
        value: balance ? String(Number(balance.annualTotal) - Number(balance.annualUsed)) : '—',
        detail: balance ? L(`of ${balance.annualTotal}`, `من ${balance.annualTotal}`) : null,
      },
      {
        label: L('Sick leave left', 'رصيد الإجازة المرضية'),
        value: balance ? String(Number(balance.sickTotal) - Number(balance.sickUsed)) : '—',
        detail: null,
      },
    ],
  })

  const reqs = await db
    .select()
    .from(requests)
    .where(eq(requests.userId, person.id))
    // Pending first: those are the ones somebody is waiting on.
    .orderBy(sql`case when ${requests.status} = 'pending' then 0 else 1 end`, desc(requests.submittedAt))
    .limit(10)

  if (reqs.length > 0) {
    sections.push({
      kind: 'table',
      heading: L('Requests', 'الطلبات'),
      columns: [L('Type', 'النوع'), L('Status', 'الحالة'), L('Dates', 'التواريخ'), L('Sent', 'أُرسل')],
      rows: reqs.map((r) => [
        r.kind,
        r.status,
        r.leaveFrom ? `${r.leaveFrom} → ${r.leaveTo}` : '—',
        r.submittedAt.toISOString().slice(0, 10),
      ]),
      note: null,
    })
  }

  const docs = await db.select().from(documents).where(eq(documents.userId, person.id))
  const cvs = await db
    .select({ fileName: cvFiles.fileName, at: cvFiles.uploadedAt })
    .from(cvFiles)
    .where(eq(cvFiles.userId, person.id))
    .orderBy(desc(cvFiles.uploadedAt))

  if (docs.length > 0 || cvs.length > 0) {
    sections.push({
      kind: 'table',
      heading: L('Files on record', 'الملفات المحفوظة'),
      columns: [L('Kind', 'النوع'), L('File', 'الملف'), L('Added', 'أُضيف')],
      rows: [
        ...cvs.map((c) => ['السيرة الذاتية', c.fileName, c.at.toISOString().slice(0, 10)]),
        ...docs.map((d) => [d.kind, d.fileName, String(d.issuedOn)]),
      ],
      note: null,
    })
  }

  /* pay — never for a manager */
  if (actor.role !== 'manager') {
    const [salary] = await db
      .select()
      .from(salaryStructures)
      .where(eq(salaryStructures.userId, person.id))
      .orderBy(desc(salaryStructures.effectiveFrom))
      .limit(1)

    if (salary) {
      sections.push({
        kind: 'stats',
        heading: L('Contracted pay', 'الراتب المتعاقد عليه'),
        stats: [
          { label: L('Basic', 'الأساسي'), value: Number(salary.basic).toFixed(2), detail: null },
          { label: L('Transport', 'مواصلات'), value: Number(salary.transport).toFixed(2), detail: null },
          { label: L('Housing', 'سكن'), value: Number(salary.housing).toFixed(2), detail: null },
          { label: L('In force since', 'ساري من'), value: String(salary.effectiveFrom), detail: null },
        ],
      })
    }

    const slips = await db
      .select({
        paidOn: payslips.paidOn,
        basic: payslips.basic,
        allow: payslips.allowances,
        ded: payslips.deductions,
      })
      .from(payslips)
      .where(eq(payslips.userId, person.id))
      .orderBy(desc(payslips.paidOn))
      .limit(6)

    if (slips.length > 0) {
      sections.push({
        kind: 'table',
        heading: L('Recent payslips', 'آخر كشوف الرواتب'),
        columns: [
          L('Paid on', 'تاريخ الصرف'),
          L('Basic', 'الأساسي'),
          L('Allowances', 'البدلات'),
          L('Deductions', 'الخصومات'),
          L('Net', 'الصافي'),
        ],
        rows: slips.map((s) => [
          String(s.paidOn),
          Number(s.basic).toFixed(2),
          Number(s.allow).toFixed(2),
          Number(s.ded).toFixed(2),
          (Number(s.basic) + Number(s.allow) - Number(s.ded)).toFixed(2),
        ]),
        note: null,
      })
    }
  }

  return {
    type: 'employeeFile',
    title: L(`Employee file — ${person.fullNameEn}`, `ملف الموظّف — ${person.fullNameAr}`),
    period: L(`${p.from} to ${p.to}`, `من ${p.from} إلى ${p.to}`),
    scope: L(person.employeeNumber, person.employeeNumber),
    generatedAt: now.toISOString(),
    generatedBy: actor.fullName,
    sections,
  }
}
