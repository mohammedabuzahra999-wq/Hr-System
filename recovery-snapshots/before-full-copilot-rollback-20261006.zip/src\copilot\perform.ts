import { and, desc, eq, ilike, or } from 'drizzle-orm'
import type {
  ActionDetail,
  ActionOutcome,
  ActionParams,
  ActionChoice,
  ActionProposal,
  CopilotActionPlan,
  SessionUser,
} from '@hr/shared'
import { db } from '../db/client.js'
import {
  announcements,
  applications,
  candidates,
  jobDescriptions,
  jobOpenings,
  requests,
  users,
} from '../db/schema.js'
import { callInternal } from '../internalApi.js'
import { dayKey } from '../domain/workdays.js'
import { DESTRUCTIVE, mayDo } from './actions.js'
import { GUIDE_PAGES } from '../guide/pages.js'

/**
 * Turning an instruction into something specific, then carrying it out.
 *
 * Two halves, and the split matters. `propose` resolves everything the model
 * left vague — which person, which request, which vacancy — and hands back a
 * description of what would happen. `run` does it, and only runs against a
 * request the person has confirmed.
 *
 * Resolution is where a careless assistant does damage, so every lookup here
 * is scoped before it searches rather than filtered afterwards: a manager
 * naming "Ahmad" searches their own reports, not the company. A name that
 * matches nobody within that scope is not found — never widened, never guessed
 * at, and never reported differently from a name that exists outside the scope,
 * because the difference between those two answers is itself information.
 */

const L = (en: string, ar: string) => ({ en, ar })

type Proposed =
  | { ok: true; proposal: ActionProposal }
  /** More than one record fits, so the person picks rather than the server guessing. */
  | { ok: true; choice: ActionChoice }
  /** `detail` names the candidates when more than one person matched. */
  | { ok: false; reason: Refusal; detail?: string; missing?: Gap }

/**
 * A detail the instruction is short of.
 *
 * `en`/`ar` are for the person. `fields` is for the resolver that reads their
 * reply: it names the plan fields the answer belongs in. Without it the reply
 * was read correctly and then dropped — asked “the job title” and told
 * “Payroll Officer”, the model agreed it was an answer and filled in nothing,
 * because a plan has both `title` and `jobTitle` and the question named
 * neither. The guard above each gap already knows which field it tested, so it
 * says which rather than leaving a model to infer it from the wording.
 */
export type Gap = {
  en: string
  ar: string
  fields: readonly (keyof CopilotActionPlan)[]
  /**
   * Whether the instruction can go ahead without it.
   *
   * A required gap is a wall: there is no leave request without dates. An
   * optional one is a question worth asking that must not become an
   * interrogation — a job description is better for knowing the seniority and
   * the skills, and somebody who just wants the draft has to be able to say so
   * and get it. Asking without a way past is how an assistant ends up worse
   * than the form it replaced.
   */
  optional: boolean
}
export type Refusal = 'notPermitted' | 'unclear' | 'notFound' | 'notApplicable' | 'ambiguous'

const STAGE_LABEL: Record<string, { en: string; ar: string }> = {
  new: L('New', 'جديد'),
  underReview: L('Under review', 'قيد المراجعة'),
  shortlisted: L('Shortlisted', 'قائمة مختصرة'),
  interview: L('Interview', 'مقابلة'),
  offer: L('Offer', 'عرض'),
  hired: L('Hired', 'تم التوظيف'),
  rejected: L('Rejected', 'مرفوض'),
}

const LEAVE_LABEL: Record<string, { en: string; ar: string }> = {
  annual: L('Annual leave', 'إجازة سنوية'),
  sick: L('Sick leave', 'إجازة مرضية'),
  unpaid: L('Unpaid leave', 'إجازة بدون راتب'),
}

const ROLE_LABEL: Record<string, { en: string; ar: string }> = {
  employee: L('Employee', 'موظف'),
  manager: L('Manager', 'مدير'),
  hr: L('HR', 'موارد بشرية'),
  admin: L('Administrator', 'مدير نظام'),
}

/** Vacancy fields, named as a person would say them rather than as columns. */
const FIELD_LABEL: Record<string, { en: string; ar: string }> = {
  title: L('a title', 'عنوان'),
  department: L('a department', 'قسم'),
  location: L('a location', 'موقع'),
  employmentType: L('an employment type', 'نوع التوظيف'),
}

const DOC_LABEL: Record<string, { en: string; ar: string }> = {
  certificate: L('Employment certificate', 'شهادة عمل'),
  detailsUpdate: L('Change to my details', 'تعديل بياناتي'),
}

/**
 * A refusal that says what it needed.
 *
 * "I did not understand" sends somebody away to rephrase with no idea what to
 * change. Naming the one missing piece — the event has no name, the date could
 * not be worked out — turns a dead end into a question they can answer.
 */
/**
 * A detail is missing, and this is the field it is missing from.
 *
 * At least one field is required by the signature, not by a convention. A gap
 * with no field named is the bug this exists to prevent: the person answers,
 * the answer is understood, and it is written nowhere. Forgetting it now fails
 * the build instead of failing quietly at the third message of a conversation.
 */
const needs = (
  en: string,
  ar: string,
  ...fields: [keyof CopilotActionPlan, ...(keyof CopilotActionPlan)[]]
) => ({ ok: false as const, reason: 'unclear' as const, missing: { en, ar, fields, optional: false } })

/**
 * Worth asking for, and not worth blocking on.
 *
 * Same shape as `needs`, so the question reaches the person the same way. The
 * difference is the way out: a reply that declines it is recorded as declined
 * and the instruction goes ahead without it, rather than asking again forever.
 */
const wants = (
  en: string,
  ar: string,
  ...fields: [keyof CopilotActionPlan, ...(keyof CopilotActionPlan)[]]
) => ({ ok: false as const, reason: 'unclear' as const, missing: { en, ar, fields, optional: true } })

const blank: ActionParams = {
  action: 'checkIn',
  targetId: null,
  leaveKind: null,
  documentKind: null,
  startDate: null,
  endDate: null,
  text: null,
  title: null,
  decision: null,
  stage: null,
  role: null,
  email: null,
  employeeNumberNew: null,
  jobTitle: null,
  department: null,
  amount: null,
  location: null,
  employmentType: null,
  language: null,
  screen: null,
}

/**
 * The people this person is allowed to name.
 *
 * A manager's scope is their own reports; HR and an administrator see everyone.
 * An employee names nobody — every action available to them is about
 * themselves, so there is no path here for them at all.
 */
async function findPerson(actor: SessionUser, name: string | null, employeeNumber: string | null) {
  const scope =
    actor.role === 'manager'
      ? eq(users.managerId, actor.id)
      : actor.role === 'hr' || actor.role === 'admin'
        ? undefined
        : eq(users.id, actor.id)

  const match = employeeNumber
    ? eq(users.employeeNumber, employeeNumber.trim())
    : name
      ? or(ilike(users.fullNameEn, `%${name.trim()}%`), ilike(users.fullNameAr, `%${name.trim()}%`))
      : undefined
  if (!match) return { kind: 'unclear' as const }

  const rows = await db
    .select({ id: users.id, en: users.fullNameEn, ar: users.fullNameAr, number: users.employeeNumber })
    .from(users)
    .where(scope ? and(scope, match) : match)
    .limit(5)

  if (rows.length === 0) return { kind: 'notFound' as const }
  /*
   * Two Ahmads is a question, not a coin toss. The alternative — picking the
   * first — resets the wrong person's password eventually, and does it quietly.
   */
  if (rows.length > 1) return { kind: 'ambiguous' as const, names: rows.map((r) => r.en) }
  return { kind: 'one' as const, person: rows[0]! }
}

/** Their pending request, which is the only kind that can be decided or cancelled. */
async function pendingRequestFor(userId: string) {
  const rows = await db
    .select()
    .from(requests)
    .where(and(eq(requests.userId, userId), eq(requests.status, 'pending')))
    .orderBy(desc(requests.submittedAt))
    .limit(5)
  return rows
}

function describeRequest(row: typeof requests.$inferSelect): ActionDetail[] {
  const out: ActionDetail[] = []
  if (row.kind === 'leave' && row.leaveType) {
    out.push({ label: L('Type', 'النوع'), value: LEAVE_LABEL[row.leaveType] ?? L(row.leaveType, row.leaveType) })
    if (row.leaveFrom && row.leaveTo) {
      const range = `${row.leaveFrom} → ${row.leaveTo}`
      out.push({ label: L('Dates', 'التواريخ'), value: L(range, range) })
    }
    if (row.leaveDays != null) {
      out.push({
        label: L('Working days', 'أيام العمل'),
        value: L(`${row.leaveDays}`, `${row.leaveDays}`),
      })
    }
  } else {
    out.push({
      label: L('Type', 'النوع'),
      value: DOC_LABEL[row.kind] ?? L(row.kind, row.kind),
    })
  }
  if (row.reason) out.push({ label: L('Reason', 'السبب'), value: L(row.reason, row.reason) })
  return out
}

/**
 * A title lookup that fails usefully.
 *
 * Matching a vacancy by name depends on the model having pulled the right words
 * out of a sentence, and at temperature zero that is *nearly* deterministic
 * rather than deterministic — the same instruction has been seen to resolve
 * and then not resolve. Tuning the prompt against that is chasing weather.
 *
 * So the failure carries the answer instead: told which vacancies exist, the
 * person names one exactly and the next attempt cannot miss. The same shape
 * works whether the model extracted nothing, extracted the wrong thing, or the
 * vacancy genuinely is not there.
 */
function couldNotFind(available: string[]): { ok: false; reason: Refusal; detail?: string } {
  if (available.length === 0) return { ok: false, reason: 'notFound' }
  /*
   * The names only. This is appended to a sentence the web app has already
   * written in the reader's language, so a prefix of my own would land in the
   * middle of an Arabic sentence in English.
   */
  return { ok: false, reason: 'notFound', detail: available.join('، ') }
}

/** The vacancies, for a lookup that has nothing to go on or found nothing. */
async function vacancyNames(): Promise<string[]> {
  const rows = await db
    .select({ en: jobOpenings.titleEn, ar: jobOpenings.titleAr })
    .from(jobOpenings)
    .limit(10)
  return rows.map((o) => o.ar || o.en)
}

/**
 * Matching a title the way a person means it, not the way it is stored.
 *
 * `ilike '%مسؤول رواتب%'` does not match "مسؤول الرواتب", because of two
 * letters nobody thinks about when they type. Arabic attaches its definite
 * article to the word, so the difference between "a payroll officer" and "the
 * payroll officer" is inside the token rather than beside it, and a substring
 * search is defeated by it. The same goes for the alef forms — أ, إ and آ are
 * the same letter to a reader and three different characters to a database.
 *
 * So both sides are flattened before they are compared, and the comparison is
 * on words rather than on a substring: every word the person typed has to
 * appear, in any order. "رواتب مسؤول" finds it too, which is how people type
 * when they are in a hurry.
 */
function normaliseTitle(text: string): string {
  return text
    .trim()
    .toLowerCase()
    .replace(/[\u064b-\u0652]/g, '')
    .replace(/[\u0623\u0625\u0622]/g, '\u0627')
    .replace(/\u0649/g, '\u064a')
    .replace(/(^|\s)\u0627\u0644/g, '$1')
    /*
     * The sound masculine plural has two endings for one word: موظفون and
     * موظفين are "employees" in two grammatical cases, and Arabic chooses
     * between them by the word's position in the sentence. Somebody typing a
     * screen's name from memory uses whichever came to mind, and the screen is
     * filed under the other. Folded to one form so both find it.
     */
    .replace(/\u0648\u0646(\s|$)/g, '\u064a\u0646$1')
    /* ة and ه are the same sound and are typed interchangeably. */
    .replace(/\u0629(\s|$)/g, '\u0647$1')
    .replace(/\s+/g, ' ')
}

interface Titled {
  id: string
  en: string
  ar: string
}

/**
 * Which of these the person meant.
 *
 * An exact match after flattening wins outright — otherwise "مهندس" would be
 * ambiguous between three engineering roles when somebody typed one of them in
 * full. Only when nothing matches exactly does it fall back to "contains every
 * word", and only then can the answer be more than one.
 */
function pickByTitle(rows: Titled[], query: string): Titled[] {
  const want = normaliseTitle(query)
  if (!want) return []

  const exact = rows.filter((r) => normaliseTitle(r.ar) === want || normaliseTitle(r.en) === want)
  if (exact.length > 0) return exact

  const words = want.split(' ').filter(Boolean)
  const hayOf = (r: Titled) => `${normaliseTitle(r.ar)} ${normaliseTitle(r.en)}`

  const all = rows.filter((r) => words.every((w) => hayOf(r).includes(w)))
  if (all.length > 0) return all

  /**
   * One word wrong should not mean not found.
   *
   * People remember a role approximately — "مسؤول ذكاء اصطناعي" for what is
   * filed as "مهندس ذكاء اصطناعي". Requiring every word turns a near miss into
   * nothing, which is unhelpful when one candidate is obviously the one meant.
   *
   * So a near miss is allowed — but only when it is unambiguous and only on
   * most of the words. Two candidates scoring the same is still a question, not
   * a coin toss, and the confirmation card names the title it settled on, so a
   * wrong guess is visible before anything happens rather than after.
   */
  if (words.length < 2) return []
  const scored = rows
    .map((r) => ({ row: r, hits: words.filter((w) => hayOf(r).includes(w)).length }))
    .filter((x) => x.hits >= Math.ceil(words.length * 0.6))
  if (scored.length === 0) return []

  const best = Math.max(...scored.map((x) => x.hits))
  const winners = scored.filter((x) => x.hits === best)
  return winners.length === 1 ? [winners[0]!.row] : []
}

/** Every vacancy, for matching against. There are never many. */
async function allOpenings(): Promise<Titled[]> {
  return db
    .select({ id: jobOpenings.id, en: jobOpenings.titleEn, ar: jobOpenings.titleAr })
    .from(jobOpenings)
}

/**
 * Every refusal an action can actually run into, in words.
 *
 * The routes raise forty-three distinct codes; twelve were named here and the
 * rest fell through to "that could not be done". Most of the remainder are
 * unreachable from an assistant action — login failures, file uploads, ids it
 * resolves itself — but the ones below are not, and each of them was a person
 * being told the system had a fault when it had a rule.
 *
 * Anything still missing falls back to the generic sentence, which is correct
 * for a genuine fault. The distinction is the point: a rule gets explained, a
 * fault gets apologised for.
 */
const REFUSAL_WORDING: Record<string, { en: string; ar: string }> = {
  cannotChangeOwnRole: L(
    'You cannot change your own role \u2014 somebody else has to.',
    '\u0645\u0627 \u0628\u062a\u0642\u062f\u0631 \u062a\u063a\u064a\u0651\u0631 \u062f\u0648\u0631\u0643 \u0623\u0646\u062a \u2014 \u0644\u0627\u0632\u0645 \u062d\u062f\u0627 \u062a\u0627\u0646\u064a.',
  ),
  openingHasApplications: L(
    'People have applied to it. Close it instead \u2014 that keeps their applications.',
    '\u0641\u064a \u0646\u0627\u0633 \u0642\u062f\u0651\u0645\u0648\u0627 \u0639\u0644\u064a\u0647\u0627. \u0633\u0643\u0651\u0631\u0647\u0627 \u0628\u062f\u0644 \u0645\u0627 \u062a\u062d\u0630\u0641\u0647\u0627 \u2014 \u0647\u064a\u0643 \u0628\u064a\u0636\u0644\u0648\u0627 \u0645\u062d\u0641\u0648\u0638\u064a\u0646.',
  ),
  payrollRunLocked: L(
    'That month is approved and cannot be recalculated.',
    '\u0647\u0627\u0644\u0634\u0647\u0631 \u0645\u0639\u062a\u0645\u062f \u0648\u0645\u0627 \u0628\u064a\u0646\u062d\u0633\u0628 \u0645\u0646 \u062c\u062f\u064a\u062f.',
  ),
  payrollRunEmpty: L(
    'Nobody has a salary set for that month, so there is nothing to calculate.',
    '\u0645\u0627 \u062d\u062f\u0627 \u0625\u0644\u0647 \u0631\u0627\u062a\u0628 \u0645\u062d\u062f\u0651\u062f \u0644\u0647\u0627\u0644\u0634\u0647\u0631\u060c \u0641\u0645\u0627 \u0641\u064a \u0625\u0634\u064a \u064a\u0646\u062d\u0633\u0628.',
  ),
  noPayrollSettings: L(
    'The tax and social security rates have not been confirmed yet. Set those first.',
    '\u0646\u0633\u0628 \u0627\u0644\u0636\u0631\u064a\u0628\u0629 \u0648\u0627\u0644\u0636\u0645\u0627\u0646 \u0645\u0627 \u0627\u0646\u0639\u062a\u0645\u062f\u062a \u0628\u0639\u062f. \u0638\u0628\u0651\u0637\u0647\u0627 \u0623\u0648\u0644.',
  ),
  payrollSettingsNotFound: L(
    'The tax and social security rates have not been confirmed yet. Set those first.',
    '\u0646\u0633\u0628 \u0627\u0644\u0636\u0631\u064a\u0628\u0629 \u0648\u0627\u0644\u0636\u0645\u0627\u0646 \u0645\u0627 \u0627\u0646\u0639\u062a\u0645\u062f\u062a \u0628\u0639\u062f. \u0638\u0628\u0651\u0637\u0647\u0627 \u0623\u0648\u0644.',
  ),
  descriptionAlreadyLinked: L(
    'That description is already attached to a vacancy.',
    '\u0647\u0627\u0644\u0648\u0635\u0641 \u0645\u0631\u0628\u0648\u0637 \u0628\u0648\u0638\u064a\u0641\u0629 \u0623\u0635\u0644\u0627\u064b.',
  ),
  emailRequired: L('An email address is needed.', '\u0644\u0627\u0632\u0645 \u0625\u064a\u0645\u064a\u0644.'),
  employeeNumberRequired: L('An employee number is needed.', '\u0644\u0627\u0632\u0645 \u0631\u0642\u0645 \u0648\u0638\u064a\u0641\u064a.'),
  accountDisabled: L('That account is disabled.', '\u0647\u0627\u0644\u062d\u0633\u0627\u0628 \u0645\u0639\u0637\u0651\u0644.'),
  requestNotPending: L(
    'That request has already been decided.',
    '\u0647\u0627\u0644\u0637\u0644\u0628 \u0627\u0646\u0628\u062a\u0651 \u0641\u064a\u0647 \u0645\u0646 \u0642\u0628\u0644.',
  ),
}

/* ---------------------------------------------------------------- propose */

/**
 * One typo away.
 *
 * "التوضيف" for "التوظيف", "الوضيفية" for "الوظيفية" — ض and ظ sit next to
 * each other in the ear and on the keyboard, and it is the most common thing to
 * get wrong when typing Arabic quickly. Exact matching turned every one of them
 * into "I could not find that screen", which is a strange thing to be told about
 * a screen that is right there in the menu.
 *
 * Used ONLY for screens, and that limit is deliberate. Opening the wrong screen
 * costs a glance and a click back. Matching a person's name or a vacancy this
 * loosely would mean approving the wrong leave request or closing the wrong
 * vacancy, so those stay exact — tolerance is proportional to what being wrong
 * would cost.
 */
function within(a: string, b: string, allowed: number): boolean {
  if (a === b) return true
  if (Math.abs(a.length - b.length) > allowed) return false
  /* Levenshtein, two rows, because the strings are a handful of characters. */
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i)
  for (let i = 1; i <= a.length; i += 1) {
    const row = [i]
    for (let j = 1; j <= b.length; j += 1) {
      row[j] = Math.min(
        prev[j]! + 1,
        row[j - 1]! + 1,
        prev[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1),
      )
    }
    prev = row
  }
  return prev[b.length]! <= allowed
}

/**
 * Every word of the request is a word of the title, give or take a letter.
 *
 * Short words must match exactly: at three letters a single edit is a different
 * word, not a slip.
 */
function nearlyTitled<T extends Titled>(rows: T[], want: string): T[] {
  const words = normaliseTitle(want).split(' ').filter(Boolean)
  if (words.length === 0) return []
  return rows.filter((r) => {
    const hay = `${normaliseTitle(r.ar)} ${normaliseTitle(r.en)}`.split(' ').filter(Boolean)
    return words.every((w) => hay.some((h) => within(w, h, w.length >= 5 ? 1 : 0)))
  })
}

export async function proposeAction(
  plan: CopilotActionPlan,
  actor: SessionUser,
  /**
   * Fields the person was asked about and chose not to fill in.
   *
   * Passed in rather than stored on the plan, because it is not something
   * anybody said — it is something they declined to say, which belongs to the
   * conversation and not to the instruction. Empty for every caller that is not
   * part-way through one, which is the MCP tools and the first message of a
   * chat.
   */
  declined: readonly (keyof CopilotActionPlan)[] = [],
): Promise<Proposed> {
  const action = plan.action

  /*
   * Checked here so the refusal is a sentence rather than a status code. It is
   * not what enforces the rule — the route does that when `run` calls it, and
   * would refuse this same action even if this check were wrong.
   */
  if (!mayDo(actor.role, action)) return { ok: false, reason: 'notPermitted' }

  const destructive = DESTRUCTIVE.has(action)
  const base = { action, destructive, caution: null as ActionProposal['caution'] }

  switch (action) {
    case 'checkIn':
    case 'checkOut': {
      const arriving = action === 'checkIn'
      return {
        ok: true,
        proposal: {
          ...base,
          summary: arriving
            ? L('Record your arrival for today', 'تسجيل حضورك لليوم')
            : L('Record your departure for today', 'تسجيل مغادرتك لليوم'),
          details: [{ label: L('Date', 'التاريخ'), value: L(dayKey(new Date()), dayKey(new Date())) }],
          params: { ...blank, action },
        },
      }
    }

    case 'requestLeave': {
      if (!plan.leaveKind) return needs('which kind of leave', 'نوع الإجازة', 'leaveKind')
      if (!plan.startDate || !plan.endDate) return needs('the dates', 'التواريخ', 'startDate', 'endDate')
      const range = `${plan.startDate} → ${plan.endDate}`
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L('Submit a leave request', 'إرسال طلب إجازة'),
          details: [
            { label: L('Type', 'النوع'), value: LEAVE_LABEL[plan.leaveKind]! },
            { label: L('Dates', 'التواريخ'), value: L(range, range) },
            ...(plan.text ? [{ label: L('Reason', 'السبب'), value: L(plan.text, plan.text) }] : []),
          ],
          params: {
            ...blank,
            action,
            leaveKind: plan.leaveKind,
            startDate: plan.startDate,
            endDate: plan.endDate,
            text: plan.text,
          },
        },
      }
    }

    case 'requestDocument': {
      /*
       * Not defaulted. This used to fall back to `certificate`, which meant a
       * sentence the classifier could not place became a formal request for an
       * employment certificate — somebody asking to switch the interface
       * language was one button away from filing one. A default here is the
       * server inventing what was asked for, which is the one thing it must
       * never do.
       */
      const kind = plan.documentKind
      if (!kind) {
        return needs(
          'which request — an employment certificate, or a change to your details',
          'أي طلب — شهادة عمل، ولا تعديل بياناتك',
          'documentKind',
        )
      }
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L('Submit a request', 'إرسال طلب'),
          details: [
            { label: L('Type', 'النوع'), value: DOC_LABEL[kind]! },
            ...(plan.text ? [{ label: L('Note', 'ملاحظة'), value: L(plan.text, plan.text) }] : []),
          ],
          params: { ...blank, action, documentKind: kind, text: plan.text },
        },
      }
    }

    /**
     * The interface language, which is this browser's preference and not a
     * record anywhere. Reversible in one press, so no caution and no
     * confirmation weight — but still a proposal, because every action is.
     */
    /**
     * Taking them to a screen, which is what a bare noun usually means.
     *
     * "الموظفون" on its own is not an instruction to do anything to
     * employees — it is somebody heading for the employees screen. Without this
     * action the classifier had to pick from a list of things that *change*
     * something, and it did: "الرواتب" proposed running the month's payroll.
     * One word, and the only options offered were consequential ones.
     *
     * Matched against the same screen registry the guide answers from, filtered
     * by role first — so a screen this person cannot open is not a screen they
     * can be sent to.
     */
    case 'openScreen': {
      const wanted = plan.screen?.trim()
      if (!wanted) return needs('which screen', '\u0623\u064a \u0634\u0627\u0634\u0629', 'screen')

      const reachable = GUIDE_PAGES.filter((g) => g.roles.includes(actor.role))
      const choices = reachable.map((g) => ({ id: g.path, en: g.title.en, ar: g.title.ar }))

      /*
       * "the leave page" is the leave page.
       *
       * Saying the word for "page" is the most ordinary way to name one, and it
       * was the single phrasing that failed: "ودّيني على الموظفين" found the
       * screen and "ودّيني على صفحة الموظفين" did not, because the extra word
       * became part of the name being looked up.
       *
       * Tried as given first, then again without it. That order is the whole
       * care in this: one of the screens is genuinely called "صفحة الوظائف",
       * and stripping the word before trying the real name would break the one
       * case where it is not noise.
       */
      const hits = (() => {
        const direct = pickByTitle(choices, wanted)
        if (direct.length > 0) return direct
        const bare = wanted
          .replace(/^(the|my)\s+/i, '')
          .replace(/\b(page|screen|tab)\b/gi, ' ')
          .replace(/(^|\s)(ال)?(صفحة|صفحه|شاشة|شاشه)(\s|$)/g, ' ')
          .replace(/\s+/g, ' ')
          .trim()
        const stripped = bare && bare !== wanted ? pickByTitle(choices, bare) : []
        if (stripped.length > 0) return stripped

        /*
         * Last: allow a slip of one letter, and only if it lands on exactly one
         * screen. Two candidates a typo apart is not a typo anybody can resolve
         * for them, so that falls through to the list.
         */
        const near = nearlyTitled(choices, bare || wanted)
        return near.length === 1 ? near : []
      })()

      if (hits.length === 0) {
        return couldNotFind(reachable.map((g) => g.title.ar || g.title.en).slice(0, 12))
      }
      if (hits.length > 1) {
        return { ok: false, reason: 'ambiguous', detail: hits.map((h) => h.ar || h.en).join('\u060c ') }
      }
      const hit = hits[0]!
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Open ${hit.en}`, `\u0641\u062a\u062d ${hit.ar}`),
          details: [{ label: L('Screen', '\u0627\u0644\u0634\u0627\u0634\u0629'), value: L(hit.en, hit.ar) }],
          params: { ...blank, action, screen: hit.id },
        },
      }
    }

    case 'setLanguage': {
      if (!plan.language) return needs('which language', 'أي لغة', 'language')
      const name = plan.language === 'ar' ? L('Arabic', 'العربية') : L('English', 'الإنجليزية')
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Switch the interface to ${name.en}`, `تحويل الواجهة إلى ${name.ar}`),
          details: [{ label: L('Language', 'اللغة'), value: name }],
          params: { ...blank, action, language: plan.language },
        },
      }
    }

    /**
     * Leaving the application, which is not the same as leaving work.
     *
     * Confirmed like everything else, and that matters more here than it looks:
     * a misheard "check me out" that signs somebody out costs them their place
     * in whatever they were doing, and the card is what lets them notice before
     * it happens rather than after.
     */
    case 'signOut':
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L('Sign out of the system', 'تسجيل الخروج من النظام'),
          details: [],
          caution: L(
            'This ends your session. It does not record the end of your working day — that is a separate action.',
            'هاد بينهي جلستك. ما بيسجّل مغادرتك من الدوام — هاي إجراء لحاله.',
          ),
          params: { ...blank, action },
        },
      }

    case 'cancelRequest': {
      const rows = await pendingRequestFor(actor.id)
      if (rows.length === 0) return { ok: false, reason: 'notFound' }

      const one = (row: (typeof rows)[number]): ActionProposal => ({
        ...base,
        summary: L('Withdraw your pending request', 'سحب طلبك المعلّق'),
        details: describeRequest(row),
        params: { ...blank, action, targetId: row.id },
      })
      if (rows.length === 1) return { ok: true, proposal: one(rows[0]!) }
      return {
        ok: true,
        choice: {
          question: L('You have more than one pending. Which?', 'عندك أكتر من طلب معلّق. أي واحد؟'),
          options: rows.map(one),
        },
      }
    }

    case 'decideRequest': {
      if (!plan.decision) return needs('whether to approve or reject', 'موافقة ولا رفض', 'decision')
      const found = await findPerson(actor, plan.personName, plan.employeeNumber)
      if (found.kind !== 'one') {
        /*
         * Saying "more than one matched" without saying which leaves the
         * person guessing at a phrasing. The names are already in hand.
         */
        return { ok: false, reason: found.kind, detail: found.kind === 'ambiguous' ? found.names.join('\u060c ') : undefined }
      }

      const rows = await pendingRequestFor(found.person.id)
      if (rows.length === 0) return { ok: false, reason: 'notApplicable' }
      const approving = plan.decision === 'approve'

      const one = (row: (typeof rows)[number]): ActionProposal => ({
        ...base,
        summary: approving
          ? L(`Approve ${found.person.en}’s request`, `الموافقة على طلب ${found.person.ar}`)
          : L(`Reject ${found.person.en}’s request`, `رفض طلب ${found.person.ar}`),
        details: [
          { label: L('Employee', 'الموظف'), value: L(found.person.en, found.person.ar) },
          ...describeRequest(row),
        ],
        caution: approving
          ? L(
              'Approving deducts the days from their balance and marks those days as leave.',
              'الموافقة بتخصم الأيام من رصيده وبتعلّم هالأيام كإجازة.',
            )
          : null,
        params: { ...blank, action, targetId: row.id, decision: plan.decision },
      })

      if (rows.length === 1) return { ok: true, proposal: one(rows[0]!) }
      return {
        ok: true,
        choice: {
          question: L(
            `${found.person.en} has more than one pending. Which?`,
            `${found.person.ar} عنده أكتر من طلب معلّق. أي واحد؟`,
          ),
          options: rows.map(one),
        },
      }
    }

    case 'postAnnouncement': {
      if (!plan.text) return needs('what the announcement should say', 'نص الإعلان', 'text')
      const title = plan.title?.trim() || plan.text.trim().slice(0, 60)
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L('Post an announcement to everyone', 'نشر إعلان للجميع'),
          details: [
            { label: L('Title', 'العنوان'), value: L(title, title) },
            { label: L('Body', 'النص'), value: L(plan.text, plan.text) },
          ],
          caution: L('Everyone sees it, with your name on it.', 'الكل بيشوفه، وعليه اسمك.'),
          params: { ...blank, action, title, text: plan.text },
        },
      }
    }

    case 'remindCheckout':
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L('Remind everyone who has not checked out', 'تذكير كل من ما سجّل مغادرة'),
          details: [],
          params: { ...blank, action },
        },
      }

    case 'resetPassword': {
      const found = await findPerson(actor, plan.personName, plan.employeeNumber)
      if (found.kind !== 'one') {
        /*
         * Saying "more than one matched" without saying which leaves the
         * person guessing at a phrasing. The names are already in hand.
         */
        return { ok: false, reason: found.kind, detail: found.kind === 'ambiguous' ? found.names.join('\u060c ') : undefined }
      }
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Reset ${found.person.en}’s password`, `تصفير كلمة سر ${found.person.ar}`),
          details: [
            { label: L('Employee', 'الموظف'), value: L(found.person.en, found.person.ar) },
            { label: L('Number', 'الرقم'), value: L(found.person.number, found.person.number) },
          ],
          caution: L(
            'Their current password stops working immediately. A temporary one is shown once.',
            'كلمة سره الحالية بتوقف فوراً. بتظهر كلمة مؤقتة مرة وحدة بس.',
          ),
          params: { ...blank, action, targetId: found.person.id },
        },
      }
    }

    /**
     * Writing one, which is the only action here that creates something from a
     * sentence rather than acting on a record that already exists.
     *
     * Everything the person said is forwarded as the prompt, and the title they
     * named as the title — the route's own rule is that one or the other must
     * be present, so a bare "write me a job description" with no role in it is
     * unclear here rather than a model inventing a job.
     */
    /**
     * Writing a job description.
     *
     * The form on the job-descriptions screen takes twelve fields. Asking those
     * twelve one at a time would be a worse form, not a conversation — the
     * whole point of a form is seeing the fields at once. So this asks twice:
     * the role, which nothing can be written without, and then everything else
     * in one question, answered in whatever words the person uses.
     *
     * The second question can be turned down. The generator takes free text as
     * an alternative to the structured fields, so a description written from
     * the title alone is a real draft — thinner, and a draft is meant to be
     * edited. Somebody who wants it now says so and gets it.
     */
    case 'generateJobDescription': {
      const title = plan.title?.trim() ?? ''
      const brief = plan.text?.trim() ?? ''
      const dept = plan.department?.trim() ?? ''
      if (!title && !brief) return needs('the job title', 'المسمّى الوظيفي', 'title')
      if (title && !brief && !declined.includes('text')) {
        return wants(
          'the seniority, the years of experience, the skills that matter',
          'المستوى، سنين الخبرة، المهارات المهمة',
          'text',
        )
      }
      return {
        ok: true,
        proposal: {
          ...base,
          summary: title
            ? L(`Write a job description for ${title}`, `كتابة وصف وظيفي لـ${title}`)
            : L('Write a job description', 'كتابة وصف وظيفي'),
          details: [
            ...(title ? [{ label: L('Role', 'الوظيفة'), value: L(title, title) }] : []),
            ...(dept ? [{ label: L('Department', 'القسم'), value: L(dept, dept) }] : []),
            ...(brief ? [{ label: L('What you said', 'اللي قلته'), value: L(brief, brief) }] : []),
          ],
          caution: L(
            'It is written as a draft for you to edit, and nothing is published until you approve it.',
            'بتنكتب كمسودة تعدّل عليها، وما بيننشر إشي لحد ما تعتمدها.',
          ),
          params: { ...blank, action, title: title || null, text: brief || null, department: dept || null },
        },
      }
    }

    case 'approveJobDescription': {
      if (!plan.title) return { ok: false, reason: 'unclear' }
      const drafts = await db
        .select({ id: jobDescriptions.id, en: jobDescriptions.titleEn, ar: jobDescriptions.titleAr })
        .from(jobDescriptions)
        .where(eq(jobDescriptions.status, 'draft'))
      const rows = pickByTitle(drafts, plan.title)
      if (rows.length === 0) {
        const drafts = await db
          .select({ en: jobDescriptions.titleEn, ar: jobDescriptions.titleAr })
          .from(jobDescriptions)
          .where(eq(jobDescriptions.status, 'draft'))
          .limit(10)
        return couldNotFind(drafts.map((d) => d.ar || d.en))
      }
      if (rows.length > 1) return { ok: false, reason: 'ambiguous', detail: rows.map((r) => r.ar || r.en).join('، ') }
      const row = rows[0]!
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Approve the job description for ${row.en}`, `اعتماد الوصف الوظيفي لـ${row.ar}`),
          details: [{ label: L('Role', 'الوظيفة'), value: L(row.en, row.ar) }],
          caution: L(
            'Approving also opens the vacancy as a draft, ready to publish.',
            'الاعتماد بيفتح الوظيفة كمسودة جاهزة للنشر.',
          ),
          params: { ...blank, action, targetId: row.id },
        },
      }
    }

    /**
     * Opening a vacancy directly.
     *
     * The usual route is through a job description: approving one opens the
     * vacancy for you. This is for when there is no description to write — a
     * role being re-advertised, or a position somebody already agreed. It is a
     * draft either way, so the decision to make it public stays a separate one.
     */
    case 'createJob': {
      if (!plan.title) return needs('the job title', '\u0645\u0633\u0645\u0651\u0649 \u0627\u0644\u0648\u0638\u064a\u0641\u0629', 'title')
      /**
       * The department, worked out rather than asked for.
       *
       * Asking "which department?" for a payroll officer is the assistant
       * making somebody do lookup work it can do itself — there is an approved
       * job description for that role and it says Finance.
       *
       * Taken from a record, never invented. If nothing in the library matches
       * the title it still asks, and says why it is asking: a department
       * nobody has written down is not something to guess at.
       */
      /**
       * A vacancy by this name is already open.
       *
       * "انشرلي وظيفة مسؤول رواتب" is an instruction to publish the one that
       * exists, and it has been read as an instruction to open another. The
       * difference between those two readings is a duplicate vacancy on a
       * public careers page — so it is settled against the database rather
       * than against the wording. If the role is already open, this is not the
       * action, whatever the sentence sounded like.
       */
      const existing = pickByTitle(await allOpenings(), plan.title)
      if (existing.length > 0) {
        const names = existing.map((o) => o.ar || o.en).join('، ')
        return {
          ok: false,
          reason: 'notApplicable',
          missing: {
            en: `nothing — a vacancy for that already exists (${names}). Ask to publish or update it instead of opening another`,
            ar: `ولا إشي — في وظيفة لهالدور أصلاً (${names}). اطلب نشرها أو تعديلها بدل ما تفتح وحدة تانية`,
            /*
             * No field, because this is not a question. It borrows the same
             * slot to say why the instruction does not apply, and there is
             * nothing the person could reply that would fill anything in — so
             * no task is left waiting on an answer.
             */
            fields: [],
            optional: false,
          },
        }
      }

      let department = plan.department
      if (!department) {
        const library = await db
          .select({
            id: jobDescriptions.id,
            en: jobDescriptions.titleEn,
            ar: jobDescriptions.titleAr,
            depEn: jobDescriptions.departmentEn,
            depAr: jobDescriptions.departmentAr,
          })
          .from(jobDescriptions)
          .where(eq(jobDescriptions.status, 'approved'))
        const hit = pickByTitle(library, plan.title)[0] as
          | (Titled & { depEn: string; depAr: string })
          | undefined
        department = hit?.depAr || hit?.depEn || null
      }
      if (!department) {
        return needs(
          'the department \u2014 there is no approved job description for that role to take it from',
          '\u0627\u0644\u0642\u0633\u0645 \u2014 \u0645\u0627 \u0641\u064a \u0648\u0635\u0641 \u0648\u0638\u064a\u0641\u064a \u0645\u0639\u062a\u0645\u062f \u0644\u0647\u0627\u0644\u0648\u0638\u064a\u0641\u0629 \u0622\u062e\u0630\u0647 \u0645\u0646\u0647',
          'department',
        )
      }

      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Open a vacancy for ${plan.title}`, `\u0641\u062a\u062d \u0648\u0638\u064a\u0641\u0629 ${plan.title}`),
          details: [
            { label: L('Role', '\u0627\u0644\u0648\u0638\u064a\u0641\u0629'), value: L(plan.title, plan.title) },
            { label: L('Department', '\u0627\u0644\u0642\u0633\u0645'), value: L(department, department) },
            ...(plan.location
              ? [{ label: L('Location', '\u0627\u0644\u0645\u0648\u0642\u0639'), value: L(plan.location, plan.location) }]
              : []),
          ],
          caution: L(
            'It is created as a draft. Publishing it to the careers page is a separate step.',
            '\u0628\u062a\u0646\u0641\u062a\u062d \u0643\u0645\u0633\u0648\u062f\u0629. \u0646\u0634\u0631\u0647\u0627 \u0639\u0644\u0649 \u0635\u0641\u062d\u0629 \u0627\u0644\u0648\u0638\u0627\u0626\u0641 \u062e\u0637\u0648\u0629 \u0644\u062d\u0627\u0644\u0647\u0627.',
          ),
          params: { ...blank, action, title: plan.title, department, location: plan.location },
        },
      }
    }

    /**
     * Filling in what publishing was refused for.
     *
     * Without this the assistant could open a vacancy, refuse to publish it for
     * a missing location, and then be unable to add the location — telling the
     * person to go and do by hand the one thing it had just stopped them doing.
     * A refusal that names a fix should be followed by a way to apply it.
     */
    case 'updateJobOpening': {
      if (!plan.title) return couldNotFind(await vacancyNames())
      if (!plan.location && !plan.employmentType && !plan.startDate) {
        return needs(
          'what to set \u2014 a location, an employment type, or a deadline',
          '\u0634\u0648 \u0628\u062f\u0643 \u062a\u0636\u0628\u0637 \u2014 \u0627\u0644\u0645\u0648\u0642\u0639\u060c \u0646\u0648\u0639 \u0627\u0644\u062a\u0648\u0638\u064a\u0641\u060c \u0648\u0644\u0627 \u0627\u0644\u0645\u0648\u0639\u062f \u0627\u0644\u0646\u0647\u0627\u0626\u064a',
          'location',
          'employmentType',
          'startDate',
        )
      }
      const rows = pickByTitle(await allOpenings(), plan.title)
      if (rows.length === 0) return couldNotFind(await vacancyNames())
      if (rows.length > 1) return { ok: false, reason: 'ambiguous', detail: rows.map((r) => r.ar || r.en).join('\u060c ') }
      const row = rows[0]!
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Update the ${row.en} vacancy`, `\u062a\u0639\u062f\u064a\u0644 \u0648\u0638\u064a\u0641\u0629 ${row.ar}`),
          details: [
            { label: L('Vacancy', '\u0627\u0644\u0648\u0638\u064a\u0641\u0629'), value: L(row.en, row.ar) },
            ...(plan.location
              ? [{ label: L('Location', '\u0627\u0644\u0645\u0648\u0642\u0639'), value: L(plan.location, plan.location) }]
              : []),
            ...(plan.employmentType
              ? [{ label: L('Employment type', '\u0646\u0648\u0639 \u0627\u0644\u062a\u0648\u0638\u064a\u0641'), value: L(plan.employmentType, plan.employmentType) }]
              : []),
            ...(plan.startDate
              ? [{ label: L('Deadline', '\u0627\u0644\u0645\u0648\u0639\u062f \u0627\u0644\u0646\u0647\u0627\u0626\u064a'), value: L(plan.startDate, plan.startDate) }]
              : []),
          ],
          params: {
            ...blank,
            action,
            targetId: row.id,
            location: plan.location,
            employmentType: plan.employmentType,
            startDate: plan.startDate,
          },
        },
      }
    }

    case 'publishOpening': {
      /* Nothing to match on: the list is more use than "be clearer". */
      if (!plan.title) return couldNotFind(await vacancyNames())
      const rows = pickByTitle(await allOpenings(), plan.title)
      if (rows.length === 0) {
        return couldNotFind(await vacancyNames())
      }
      if (rows.length > 1) return { ok: false, reason: 'ambiguous', detail: rows.map((r) => r.ar || r.en).join('، ') }
      const row = rows[0]!
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Publish the ${row.en} vacancy`, `نشر وظيفة ${row.ar}`),
          details: [{ label: L('Vacancy', 'الوظيفة'), value: L(row.en, row.ar) }],
          caution: L(
            'It goes on the public careers page, where anyone can read it.',
            'بتروح على صفحة الوظائف العامة، وأي حدا بيقدر يشوفها.',
          ),
          params: { ...blank, action, targetId: row.id },
        },
      }
    }

    case 'moveApplication':
    case 'analyseApplication': {
      if (!plan.personName) return { ok: false, reason: 'unclear' }
      const rows = await db
        .select({
          id: applications.id,
          name: candidates.fullName,
          title: jobOpenings.titleEn,
          titleAr: jobOpenings.titleAr,
        })
        .from(applications)
        .innerJoin(candidates, eq(candidates.id, applications.candidateId))
        .innerJoin(jobOpenings, eq(jobOpenings.id, applications.openingId))
        .where(ilike(candidates.fullName, `%${plan.personName.trim()}%`))
        .limit(2)
      if (rows.length === 0) return { ok: false, reason: 'notFound' }
      if (rows.length > 1) return { ok: false, reason: 'ambiguous' }
      const row = rows[0]!

      if (action === 'analyseApplication') {
        return {
          ok: true,
          proposal: {
            ...base,
            summary: L(`Read ${row.name}’s CV again`, `إعادة قراءة السيرة الذاتية لـ${row.name}`),
            details: [
              { label: L('Applicant', 'المتقدم'), value: L(row.name, row.name) },
              { label: L('Vacancy', 'الوظيفة'), value: L(row.title, row.titleAr) },
            ],
            params: { ...blank, action, targetId: row.id },
          },
        }
      }

      if (!plan.stage) return { ok: false, reason: 'unclear' }
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Move ${row.name} to ${STAGE_LABEL[plan.stage]!.en}`, `نقل ${row.name} إلى ${STAGE_LABEL[plan.stage]!.ar}`),
          details: [
            { label: L('Applicant', 'المتقدم'), value: L(row.name, row.name) },
            { label: L('Vacancy', 'الوظيفة'), value: L(row.title, row.titleAr) },
            { label: L('New stage', 'المرحلة الجديدة'), value: STAGE_LABEL[plan.stage]! },
          ],
          params: { ...blank, action, targetId: row.id, stage: plan.stage },
        },
      }
    }

    case 'deleteAnnouncement': {
      if (!plan.title) return { ok: false, reason: 'unclear' }
      const rows = await db
        .select({ id: announcements.id, en: announcements.titleEn, ar: announcements.titleAr })
        .from(announcements)
        .where(
          or(
            ilike(announcements.titleEn, `%${plan.title.trim()}%`),
            ilike(announcements.titleAr, `%${plan.title.trim()}%`),
          ),
        )
        .limit(2)
      if (rows.length === 0) return { ok: false, reason: 'notFound' }
      if (rows.length > 1) return { ok: false, reason: 'ambiguous' }
      const row = rows[0]!
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Take down “${row.en}”`, `سحب “${row.ar}”`),
          details: [{ label: L('Announcement', 'الإعلان'), value: L(row.en, row.ar) }],
          caution: L('It disappears for everyone. It cannot be restored.', 'بيختفي عن الكل، وما بيرجع.'),
          params: { ...blank, action, targetId: row.id },
        },
      }
    }

    case 'addCalendarEvent': {
      if (!plan.title) return needs('a name for the event', 'اسم للحدث', 'title')
      if (!plan.startDate) return needs('a date I can pin down', 'تاريخ محدد', 'startDate')
      const from = plan.startDate
      const to = plan.endDate ?? plan.startDate
      const range = from === to ? from : `${from} → ${to}`
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Put “${plan.title}” on the calendar`, `إضافة “${plan.title}” على التقويم`),
          details: [
            { label: L('Event', 'الحدث'), value: L(plan.title, plan.title) },
            { label: L('When', 'متى'), value: L(range, range) },
          ],
          params: { ...blank, action, title: plan.title, startDate: from, endDate: to },
        },
      }
    }

    case 'changeEmployeeRole': {
      if (!plan.role) return needs('which role', 'الدور الجديد', 'role')
      const found = await findPerson(actor, plan.personName, plan.employeeNumber)
      if (found.kind !== 'one') {
        /*
         * Saying "more than one matched" without saying which leaves the
         * person guessing at a phrasing. The names are already in hand.
         */
        return { ok: false, reason: found.kind, detail: found.kind === 'ambiguous' ? found.names.join('\u060c ') : undefined }
      }
      const label = ROLE_LABEL[plan.role]!
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Make ${found.person.en} ${label.en.toLowerCase()}`, `جعل ${found.person.ar} ${label.ar}`),
          details: [
            { label: L('Employee', 'الموظف'), value: L(found.person.en, found.person.ar) },
            { label: L('New role', 'الدور الجديد'), value: label },
          ],
          caution: L(
            'This changes what they can see and do across the whole system.',
            'هاد بيغيّر شو بيشوف وشو بيعمل بالنظام كله.',
          ),
          params: { ...blank, action, targetId: found.person.id, role: plan.role },
        },
      }
    }

    /**
     * Stopping a vacancy, which is what "close it" means and is not deleting.
     *
     * Asking to close one was reaching `deleteOpening`, which destroys the
     * vacancy and every application sent to it. Two words apart in the
     * instruction, unrecoverable apart in effect — so closing exists in its own
     * right rather than being a gentler reading of delete.
     */
    case 'closeOpening': {
      if (!plan.title) return couldNotFind(await vacancyNames())
      const rows = pickByTitle(await allOpenings(), plan.title)
      if (rows.length === 0) return couldNotFind(await vacancyNames())
      if (rows.length > 1) return { ok: false, reason: 'ambiguous', detail: rows.map((r) => r.ar || r.en).join('، ') }
      const row = rows[0]!
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Close the ${row.en} vacancy`, `إغلاق وظيفة ${row.ar}`),
          details: [{ label: L('Vacancy', 'الوظيفة'), value: L(row.en, row.ar) }],
          caution: L(
            'It stops taking applications and comes off the careers page. Everything already sent to it is kept, and it can be reopened.',
            'بتوقف عن استقبال الطلبات وبتنشال من صفحة الوظائف. كل اللي إجا عليها بيضل محفوظ، وبتقدر تفتحها من جديد.',
          ),
          params: { ...blank, action, targetId: row.id },
        },
      }
    }

    case 'deleteOpening': {
      /* Nothing to match on: the list is more use than "be clearer". */
      if (!plan.title) return couldNotFind(await vacancyNames())
      const rows = pickByTitle(await allOpenings(), plan.title)
      if (rows.length === 0) return couldNotFind(await vacancyNames())
      if (rows.length > 1) return { ok: false, reason: 'ambiguous', detail: rows.map((r) => r.ar || r.en).join('، ') }
      const row = rows[0]!
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Delete the ${row.en} vacancy`, `حذف وظيفة ${row.ar}`),
          details: [{ label: L('Vacancy', 'الوظيفة'), value: L(row.en, row.ar) }],
          caution: L(
            'Applications sent to it go with it. This cannot be undone.',
            'الطلبات اللي إجت عليها بتروح معها. ما بترجع.',
          ),
          params: { ...blank, action, targetId: row.id },
        },
      }
    }

    /**
     * Creating an account, which needs more than one sentence usually carries.
     *
     * So the refusal lists exactly what is still missing rather than saying the
     * instruction was unclear — the person can then say the rest in one go
     * instead of guessing at what a complete sentence looks like.
     *
     * The Arabic and English name are set to the same text: the person gave one
     * name, and inventing a transliteration of it would put a spelling in the
     * directory that nobody chose.
     */
    case 'addEmployee': {
      const want: { key: keyof CopilotActionPlan; field: string; en: string; ar: string }[] = [
        { key: 'personName', field: plan.personName ?? '', en: 'their full name', ar: 'الاسم الكامل' },
        { key: 'email', field: plan.email ?? '', en: 'an email address', ar: 'الإيميل' },
        { key: 'employeeNumberNew', field: plan.employeeNumberNew ?? '', en: 'an employee number', ar: 'الرقم الوظيفي' },
        { key: 'jobTitle', field: plan.jobTitle ?? '', en: 'a job title', ar: 'المسمّى الوظيفي' },
        { key: 'department', field: plan.department ?? '', en: 'a department', ar: 'القسم' },
      ]
      const gaps = want.filter((w) => !w.field.trim())
      if (gaps.length > 0) {
        return needs(
          gaps.map((g) => g.en).join(', '),
          gaps.map((g) => g.ar).join('، '),
          /* Split so the type carries what the guard above already proved: there is at least one. */
          gaps[0]!.key,
          ...gaps.slice(1).map((g) => g.key),
        )
      }
      const role = plan.role ?? 'employee'
      const name = plan.personName!.trim()
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Create an account for ${name}`, `إنشاء حساب لـ${name}`),
          details: [
            { label: L('Name', 'الاسم'), value: L(name, name) },
            { label: L('Email', 'الإيميل'), value: L(plan.email!, plan.email!) },
            { label: L('Number', 'الرقم'), value: L(plan.employeeNumberNew!, plan.employeeNumberNew!) },
            { label: L('Job title', 'المسمّى'), value: L(plan.jobTitle!, plan.jobTitle!) },
            { label: L('Department', 'القسم'), value: L(plan.department!, plan.department!) },
            { label: L('Role', 'الدور'), value: ROLE_LABEL[role]! },
          ],
          caution: L(
            'They cannot sign in until a password is set for them — use a reset to issue one.',
            'ما بيقدر يدخل لحد ما تنحط له كلمة سر — اعملله تصفير.',
          ),
          params: {
            ...blank,
            action,
            title: name,
            email: plan.email,
            employeeNumberNew: plan.employeeNumberNew,
            jobTitle: plan.jobTitle,
            department: plan.department,
            role,
          },
        },
      }
    }

    case 'updateEmployeeDetails': {
      if (!plan.jobTitle && !plan.department) {
        return needs('what to change — job title or department', 'شو بدك تغيّر — المسمّى ولا القسم', 'jobTitle', 'department')
      }
      const found = await findPerson(actor, plan.personName, plan.employeeNumber)
      if (found.kind !== 'one') {
        return { ok: false, reason: found.kind, detail: found.kind === 'ambiguous' ? found.names.join('، ') : undefined }
      }
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(`Update ${found.person.en}’s details`, `تعديل بيانات ${found.person.ar}`),
          details: [
            { label: L('Employee', 'الموظف'), value: L(found.person.en, found.person.ar) },
            ...(plan.jobTitle
              ? [{ label: L('New job title', 'المسمّى الجديد'), value: L(plan.jobTitle, plan.jobTitle) }]
              : []),
            ...(plan.department
              ? [{ label: L('New department', 'القسم الجديد'), value: L(plan.department, plan.department) }]
              : []),
          ],
          params: {
            ...blank,
            action,
            targetId: found.person.id,
            jobTitle: plan.jobTitle,
            department: plan.department,
          },
        },
      }
    }

    /**
     * Setting what somebody earns.
     *
     * The confirmation shows the figure and the date together, because those
     * two are the whole decision: the same number from a different month is a
     * different amount of money. Marked destructive not because it cannot be
     * corrected — a correction is another agreement — but because it changes
     * what a person is paid, and that deserves a second look.
     */
    case 'setSalary': {
      /*
       * People say "950 dinars", not "950", and the model passes that through
       * as written — correctly, since it was told to copy what they said.
       * Rejecting it would refuse a perfectly clear instruction over a currency
       * word, so the figure is lifted out of whatever it came wrapped in.
       * Anything that is not exactly one number is still refused: "950 or 1000"
       * has no single answer, and picking one would be inventing a salary.
       */
      const figures = plan.amount?.match(/\d+(?:\.\d{1,2})?/g) ?? []
      if (figures.length !== 1) return needs('the amount', '\u0627\u0644\u0645\u0628\u0644\u063a', 'amount')
      const amountText = figures[0]!
      const found = await findPerson(actor, plan.personName, plan.employeeNumber)
      if (found.kind !== 'one') {
        return { ok: false, reason: found.kind, detail: found.kind === 'ambiguous' ? found.names.join('\u060c ') : undefined }
      }

      /*
       * The first of next month when they did not say, because that is what a
       * raise usually means and a mid-month start splits a payslip in a way
       * nobody asked for. Said on the card either way, so the default is never
       * silent.
       */
      const now = new Date()
      const from =
        plan.startDate ?? dayKey(new Date(now.getFullYear(), now.getMonth() + 1, 1))
      const amount = amountText

      return {
        ok: true,
        proposal: {
          ...base,
          summary: L(
            `Set ${found.person.en}\u2019s basic salary to ${amount}`,
            `\u062a\u062d\u062f\u064a\u062f \u0627\u0644\u0631\u0627\u062a\u0628 \u0627\u0644\u0623\u0633\u0627\u0633\u064a \u0644\u0640${found.person.ar} \u0628\u0640${amount}`,
          ),
          details: [
            { label: L('Employee', '\u0627\u0644\u0645\u0648\u0638\u0641'), value: L(found.person.en, found.person.ar) },
            { label: L('Basic salary', '\u0627\u0644\u0631\u0627\u062a\u0628 \u0627\u0644\u0623\u0633\u0627\u0633\u064a'), value: L(amount, amount) },
            { label: L('Applies from', '\u064a\u0637\u0628\u0651\u0642 \u0645\u0646'), value: L(from, from) },
          ],
          caution: L(
            'This starts a new agreement from that date. Allowances are not changed \u2014 set those on the payroll screen.',
            '\u0647\u0627\u062f \u0628\u064a\u0628\u0644\u0651\u0634 \u0627\u062a\u0641\u0627\u0642 \u062c\u062f\u064a\u062f \u0645\u0646 \u0647\u0627\u0644\u062a\u0627\u0631\u064a\u062e. \u0627\u0644\u0628\u062f\u0644\u0627\u062a \u0645\u0627 \u0628\u062a\u062a\u063a\u064a\u0651\u0631 \u2014 \u0638\u0628\u0651\u0637\u0647\u0627 \u0645\u0646 \u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0648\u0627\u062a\u0628.',
          ),
          params: { ...blank, action, targetId: found.person.id, amount, startDate: from },
        },
      }
    }

    case 'runPayroll': {
      const now = new Date()
      const period = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
      return {
        ok: true,
        proposal: {
          ...base,
          summary: L('Calculate this month’s payroll', 'حساب رواتب هذا الشهر'),
          details: [{ label: L('Period', 'الفترة'), value: L(period, period) }],
          caution: L(
            'This calculates the run. It does not approve or pay it.',
            'هذا بيحسب الدورة بس. ما بيعتمدها ولا بيدفعها.',
          ),
          params: { ...blank, action },
        },
      }
    }
  }
}

/* -------------------------------------------------------------------- run */

/**
 * Carrying out a confirmed action, through the route that already does it.
 *
 * Nothing here writes to a table. Each case builds a request against the same
 * endpoint the browser uses, carrying the asker's own session, so the
 * permission check, the validation, the balance, the notification and the
 * realtime event all happen exactly once and in one place.
 */
export async function runAction(params: ActionParams, actor: SessionUser, cookie: string): Promise<ActionOutcome> {
  if (!mayDo(actor.role, params.action)) {
    return {
      ok: false,
      message: L('Your role does not cover that.', 'دورك ما بيغطي هالإشي.'),
      messageKey: null,
      messageParams: null,
      path: null,
    }
  }

  const fail = (en: string, ar: string): ActionOutcome => ({
    ok: false,
    message: L(en, ar),
    messageKey: null,
    messageParams: null,
    path: null,
  })

  /**
   * The route's own reason, where there is wording for it.
   *
   * Called instead of `fail` wherever a refusal might be a rule rather than a
   * fault, so a case nobody thought to handle still says something true.
   */
  const explain = (code: string | null, en: string, ar: string): ActionOutcome => {
    const known = code ? REFUSAL_WORDING[code] : null
    return known
      ? { ok: false, message: known, messageKey: null, messageParams: null, path: null }
      : fail(en, ar)
  }
  const need = (id: string | null) => {
    if (!id) throw new Error('an action that needs a target was confirmed without one')
    return id
  }

  switch (params.action) {
    case 'checkIn':
    case 'checkOut': {
      const arriving = params.action === 'checkIn'
      const r = await callInternal({
        method: 'POST',
        path: arriving ? '/attendance/check-in' : '/attendance/check-out',
        cookie,
      })
      if (!r.ok) {
        /*
         * Every refusal the attendance routes issue, named.
         *
         * `alreadyCheckedOut` was missing, so somebody who had finished their
         * day and asked again was told "I could not record that" — which
         * sounds like a fault in the system rather than a day already
         * recorded, and invites them to keep trying.
         */
        switch (r.error) {
          case 'alreadyCheckedIn':
            return fail('You are already checked in for today.', 'أنت مسجّل حضور اليوم أصلاً.')
          case 'alreadyCheckedOut':
            return fail(
              'Your day is already recorded — you checked out earlier.',
              'دوامك مسجّل خلص — سجّلت مغادرتك قبل شوي.',
            )
          case 'notCheckedIn':
            return fail(
              'You have not checked in today, so there is no departure to record.',
              'ما سجّلت حضور اليوم، فما في مغادرة تنسجّل.',
            )
          default:
            return fail('That could not be recorded.', 'ما قدرت أسجّلها.')
        }
      }
      return {
        ok: true,
        messageKey: null,
        messageParams: null,
        message: arriving ? L('Your arrival is recorded.', 'انسجّل حضورك.') : L('Your departure is recorded.', 'انسجّلت مغادرتك.'),
        path: '/home',
      }
    }

    case 'requestLeave': {
      const r = await callInternal({
        method: 'POST',
        path: '/requests/leave',
        cookie,
        body: {
          type: params.leaveKind,
          from: params.startDate,
          to: params.endDate,
          ...(params.text ? { reason: params.text } : {}),
        },
      })
      if (!r.ok) {
        /*
         * The leave rules refuse for specific reasons — the range is all
         * weekend, the balance is short, it overlaps a request already in. The
         * leave form explains each of those already, so the refusal travels as
         * that form's key rather than as a second sentence saying the same
         * thing slightly differently.
         */
        const problem = (r.data as { problem?: Record<string, unknown> } | null)?.problem
        const code = typeof problem?.code === 'string' ? problem.code : null
        if (!code) return fail('The request was refused.', 'الطلب انرفض.')

        const params: Record<string, string> = {}
        if (code === 'errOverlap' && problem?.from && problem?.to) {
          params.range = `${String(problem.from)} → ${String(problem.to)}`
        }
        if (code === 'errBalance') {
          params.days = String(problem?.available ?? 0)
          params.type = params.type ?? ''
        }
        return {
          ok: false,
          message: L('The request was refused.', 'الطلب انرفض.'),
          messageKey: `leaveForm.${code}`,
          messageParams: Object.keys(params).length ? params : null,
          path: null,
        }
      }
      return { ok: true, message: L('Your leave request is submitted.', 'انبعث طلب إجازتك.'), messageKey: null, messageParams: null, path: '/home' }
    }

    case 'requestDocument': {
      const r = await callInternal({
        method: 'POST',
        path: '/requests/simple',
        cookie,
        body: { kind: params.documentKind, ...(params.text ? { reason: params.text } : {}) },
      })
      if (!r.ok) return explain(r.error, 'The request was refused.', 'الطلب انرفض.')
      return { ok: true, message: L('Your request is submitted.', 'انبعث طلبك.'), messageKey: null, messageParams: null, path: '/home' }
    }

    case 'signOut': {
      const r = await callInternal({ method: 'POST', path: '/auth/logout', cookie })
      if (!r.ok) return fail('You were not signed out.', 'ما انسجّل خروجك.')
      return {
        ok: true,
        message: L('Signed out.', 'انسجّل خروجك.'),
        messageKey: null,
        messageParams: null,
        path: null,
        /* the session is gone; the interface has to stop pretending otherwise */
        uiEffect: { kind: 'signedOut' },
      }
    }

    case 'openScreen': {
      /*
       * Nothing to call — but it does have to actually happen.
       *
       * This first returned a path and the sentence "here you go", which the
       * panel rendered as a link. The person had already confirmed, so they
       * were told it was done and then shown a button to do it: the message
       * described an action nobody had taken. Confirming IS the press, so the
       * effect goes back as a navigation the interface performs.
       */
      const to = params.screen ?? '/'
      return {
        ok: true,
        message: L('Opening it.', '\u0639\u0645 \u0623\u0641\u062a\u062d\u0647\u0627.'),
        messageKey: null,
        messageParams: null,
        path: to,
        uiEffect: { kind: 'navigate', path: to },
      }
    }

    case 'setLanguage': {
      /*
       * The only action here that does not call a route, because there is no
       * route to call: nothing in the database changes. The interface acts on
       * `uiEffect`, and `ok` is true because the instruction was understood and
       * is being carried out — not because a backend confirmed a write, which
       * is what it means everywhere else.
       */
      const language = params.language ?? 'ar'
      return {
        ok: true,
        message:
          language === 'ar'
            ? L('Switched to Arabic.', 'تحوّلت للعربية.')
            : L('Switched to English.', 'تحوّلت للإنجليزية.'),
        messageKey: null,
        messageParams: null,
        path: null,
        uiEffect: { kind: 'setLanguage', language },
      }
    }

    case 'cancelRequest': {
      const r = await callInternal({ method: 'POST', path: `/requests/${need(params.targetId)}/cancel`, cookie })
      if (!r.ok) {
        return r.error === 'requestNotPending'
          ? fail('That request has already been decided.', 'هالطلب انبتّ فيه من قبل.')
          : fail('That could not be withdrawn.', 'ما قدرت أسحبه.')
      }
      return { ok: true, message: L('Your request is withdrawn.', 'انسحب طلبك.'), messageKey: null, messageParams: null, path: '/home' }
    }

    case 'decideRequest': {
      const r = await callInternal({
        method: 'POST',
        path: `/requests/${need(params.targetId)}/decide`,
        cookie,
        body: { decision: params.decision === 'approve' ? 'approved' : 'rejected' },
      })
      if (!r.ok) {
        return r.error === 'requestNotPending'
          ? fail('That request has already been decided.', 'هالطلب انبتّ فيه من قبل.')
          : r.status === 403
            ? fail('That employee does not report to you.', 'هالموظف مش من فريقك.')
            : fail('The decision could not be recorded.', 'ما قدرت أسجّل القرار.')
      }
      return {
        ok: true,
        messageKey: null,
        messageParams: null,
        message:
          params.decision === 'approve'
            ? L('The request is approved.', 'انوافق على الطلب.')
            : L('The request is rejected.', 'انرفض الطلب.'),
        path: '/manager/approvals',
      }
    }

    case 'postAnnouncement': {
      const r = await callInternal({
        method: 'POST',
        path: '/feed/announcements',
        cookie,
        body: {
          title: { en: params.title ?? '', ar: params.title ?? '' },
          detail: { en: params.text ?? '', ar: params.text ?? '' },
        },
      })
      if (!r.ok) return explain(r.error, 'The announcement was not posted.', 'الإعلان ما اننشر.')
      return { ok: true, message: L('Your announcement is posted.', 'اننشر إعلانك.'), messageKey: null, messageParams: null, path: null }
    }

    case 'remindCheckout': {
      const r = await callInternal({ method: 'POST', path: '/attendance/remind-checkout', cookie })
      if (!r.ok) return fail('The reminders were not sent.', 'التذكيرات ما انبعثت.')
      const sent = (r.data as { reminded?: number } | null)?.reminded ?? 0
      return {
        ok: true,
        messageKey: null,
        messageParams: null,
        message: L(`Reminded ${sent} people.`, `انبعث تذكير لـ${sent} أشخاص.`),
        path: null,
      }
    }

    case 'resetPassword': {
      const r = await callInternal({
        method: 'POST',
        path: `/employees/${need(params.targetId)}/reset-password`,
        cookie,
      })
      if (!r.ok) return explain(r.error, 'The password was not reset.', 'كلمة السر ما انصفّرت.')
      /*
       * The temporary password is shown on the employee's own screen, not
       * repeated here. A one-time secret read out in a chat transcript is a
       * secret with a copy of itself sitting in a scrollback.
       */
      return {
        ok: true,
        messageKey: null,
        messageParams: null,
        message: L(
          'Done. Open the employee’s record to read the temporary password once.',
          'تم. افتح ملف الموظف عشان تقرأ الكلمة المؤقتة مرة وحدة.',
        ),
        path: '/hr/employees',
      }
    }

    case 'generateJobDescription': {
      const r = await callInternal({
        method: 'POST',
        path: '/job-descriptions/generate',
        cookie,
        body: {
          ...(params.title ? { title: params.title } : {}),
          ...(params.text ? { prompt: params.text } : {}),
          /* Collected by the form, so it has to arrive — a box that is filled in and dropped is a lie. */
          ...(params.department ? { department: params.department } : {}),
        },
      })
      if (!r.ok) {
        return r.error === 'aiNotConfigured'
          ? fail('No model is configured, so it was arranged from what you said instead.', 'ما في نموذج مضبوط، فانرتّب اللي قلته زي ما هو.')
          : fail('The job description was not written.', 'الوصف الوظيفي ما انكتب.')
      }
      return {
        ok: true,
        messageKey: null,
        messageParams: null,
        message: L(
          'Written, as a draft. Open it to read and edit before approving.',
          'انكتب كمسودة. افتحه واقرأه وعدّل عليه قبل ما تعتمده.',
        ),
        path: '/hr/job-descriptions',
      }
    }

    case 'approveJobDescription': {
      const r = await callInternal({
        method: 'POST',
        path: `/job-descriptions/${need(params.targetId)}/approve`,
        cookie,
      })
      if (!r.ok) {
        return r.error === 'alreadyApproved'
          ? fail('That one is already approved.', 'هاد معتمد من قبل.')
          : fail('It was not approved.', 'ما انعتمد.')
      }
      return {
        ok: true,
        messageKey: null,
        messageParams: null,
        message: L('Approved. The vacancy is open as a draft.', 'انعتمد. والوظيفة انفتحت كمسودة.'),
        path: '/hr/recruitment',
      }
    }

    case 'createJob': {
      const both = (v: string | null) => ({ en: v ?? '', ar: v ?? '' })
      const r = await callInternal({
        method: 'POST',
        path: '/recruitment/openings',
        cookie,
        body: {
          title: both(params.title),
          department: both(params.department),
          openedOn: dayKey(new Date()),
          ...(params.location ? { location: both(params.location) } : {}),
        },
      })
      if (!r.ok) return fail('The vacancy was not opened.', '\u0627\u0644\u0648\u0638\u064a\u0641\u0629 \u0645\u0627 \u0627\u0646\u0641\u062a\u062d\u062a.')
      return {
        ok: true,
        message: L('The vacancy is open, as a draft.', '\u0627\u0646\u0641\u062a\u062d\u062a \u0627\u0644\u0648\u0638\u064a\u0641\u0629 \u0643\u0645\u0633\u0648\u062f\u0629.'),
        messageKey: null,
        messageParams: null,
        path: '/hr/recruitment',
      }
    }

    case 'updateJobOpening': {
      const both = (v: string | null) => ({ en: v ?? '', ar: v ?? '' })
      const r = await callInternal({
        method: 'PATCH',
        path: `/recruitment/openings/${need(params.targetId)}`,
        cookie,
        body: {
          ...(params.location ? { location: both(params.location) } : {}),
          ...(params.employmentType ? { employmentType: params.employmentType } : {}),
          ...(params.startDate ? { deadline: params.startDate } : {}),
        },
      })
      if (!r.ok) return explain(r.error, 'The vacancy was not updated.', '\u0627\u0644\u0648\u0638\u064a\u0641\u0629 \u0645\u0627 \u0627\u0646\u0639\u062f\u0651\u0644\u062a.')
      return {
        ok: true,
        message: L('The vacancy is updated.', '\u0627\u0646\u0639\u062f\u0651\u0644\u062a \u0627\u0644\u0648\u0638\u064a\u0641\u0629.'),
        messageKey: null,
        messageParams: null,
        path: '/hr/recruitment',
      }
    }

    case 'publishOpening': {
      const r = await callInternal({
        method: 'POST',
        path: `/recruitment/openings/${need(params.targetId)}/publish`,
        cookie,
        body: { platforms: ['careers'] },
      })
      if (!r.ok) {
        /*
         * The publish workflow refuses an incomplete vacancy and says which
         * fields are missing. Reporting that as "it was not published" throws
         * away the only part that helps — the person is left pressing the same
         * button on the same vacancy, which will refuse for the same reason
         * every time.
         */
        const missing = (r.data as { missing?: string[] } | null)?.missing ?? []
        if (r.error === 'openingIncomplete' && missing.length > 0) {
          const en = missing.map((f) => FIELD_LABEL[f]?.en ?? f).join(', ')
          const ar = missing.map((f) => FIELD_LABEL[f]?.ar ?? f).join('، ')
          return fail(
            `The vacancy is missing ${en}. Fill that in on the recruitment screen, then publish.`,
            `الوظيفة ناقصها ${ar}. عبّيها من شاشة التوظيف وبعدين انشر.`,
          )
        }
        if (r.error === 'openingHasNoDescription') {
          return fail(
            'It has no job description yet. Write one and approve it first.',
            'ما إلها وصف وظيفي بعد. اكتب واحد واعتمده أول.',
          )
        }
        if (r.error === 'descriptionNotApproved') {
          return fail(
            'Its job description is still a draft. Approve that first.',
            'الوصف الوظيفي لسا مسودة. اعتمده أول.',
          )
        }
        return fail('It was not published.', 'ما اننشرت.')
      }
      return { ok: true, message: L('The vacancy is live.', 'الوظيفة صارت منشورة.'), messageKey: null, messageParams: null, path: '/hr/recruitment' }
    }

    case 'moveApplication': {
      const r = await callInternal({
        method: 'PATCH',
        path: `/recruitment/applications/${need(params.targetId)}`,
        cookie,
        body: { status: params.stage },
      })
      if (!r.ok) return explain(r.error, 'The application was not moved.', 'الطلب ما انتقل.')
      return { ok: true, message: L('The application is moved.', 'انتقل الطلب.'), messageKey: null, messageParams: null, path: '/hr/recruitment' }
    }

    case 'analyseApplication': {
      const r = await callInternal({
        method: 'POST',
        path: `/recruitment/applications/${need(params.targetId)}/analyse`,
        cookie,
      })
      if (!r.ok) return explain(r.error, 'The CV could not be read again.', 'ما قدرت أعيد قراءة السيرة.')
      return {
        ok: true,
        messageKey: null,
        messageParams: null,
        message: L('Reading the CV — the score appears shortly.', 'عم بقرأ السيرة — العلامة بتظهر بعد شوي.'),
        path: '/hr/recruitment',
      }
    }

    case 'deleteAnnouncement': {
      const r = await callInternal({ method: 'DELETE', path: `/feed/announcements/${need(params.targetId)}`, cookie })
      if (!r.ok) return explain(r.error, 'It was not taken down.', 'ما انسحب.')
      return {
        ok: true,
        message: L('The announcement is down.', 'انسحب الإعلان.'),
        messageKey: null,
        messageParams: null,
        path: null,
      }
    }

    case 'addCalendarEvent': {
      const from = params.startDate!
      const to = params.endDate ?? from
      /*
       * A day, not a moment. Somebody saying "put the team meeting on Monday"
       * has given a date and no time, and inventing 09:00 for them would put a
       * specific hour on the calendar that nobody chose. The event is all-day
       * and they can narrow it on the calendar screen.
       */
      const r = await callInternal({
        method: 'POST',
        path: '/calendar',
        cookie,
        body: {
          kind: 'meeting',
          title: { en: params.title ?? '', ar: params.title ?? '' },
          startsAt: new Date(`${from}T00:00:00`).toISOString(),
          endsAt: new Date(`${to}T23:59:00`).toISOString(),
          allDay: true,
          audience: 'team',
        },
      })
      if (!r.ok) return explain(r.error, 'The event was not added.', 'الحدث ما انضاف.')
      return {
        ok: true,
        message: L('It is on the calendar.', 'انضاف على التقويم.'),
        messageKey: null,
        messageParams: null,
        path: '/manager/calendar',
      }
    }

    case 'changeEmployeeRole': {
      const r = await callInternal({
        method: 'PATCH',
        path: `/employees/${need(params.targetId)}`,
        cookie,
        body: { role: params.role },
      })
      if (!r.ok) return explain(r.error, 'The role was not changed.', 'الدور ما انغيّر.')
      return {
        ok: true,
        message: L('The role is changed.', 'انغيّر الدور.'),
        messageKey: null,
        messageParams: null,
        path: '/admin/users',
      }
    }

    case 'closeOpening': {
      const r = await callInternal({
        method: 'PATCH',
        path: `/recruitment/openings/${need(params.targetId)}`,
        cookie,
        body: { status: 'closed' },
      })
      if (!r.ok) return explain(r.error, 'The vacancy was not closed.', 'الوظيفة ما انغلقت.')
      return {
        ok: true,
        message: L('The vacancy is closed.', 'انغلقت الوظيفة.'),
        messageKey: null,
        messageParams: null,
        path: '/hr/recruitment',
      }
    }

    case 'deleteOpening': {
      const r = await callInternal({
        method: 'DELETE',
        path: `/recruitment/openings/${need(params.targetId)}`,
        cookie,
      })
      if (!r.ok) return explain(r.error, 'The vacancy was not deleted.', 'الوظيفة ما انحذفت.')
      return {
        ok: true,
        message: L('The vacancy is deleted.', 'انحذفت الوظيفة.'),
        messageKey: null,
        messageParams: null,
        path: '/hr/recruitment',
      }
    }

    case 'addEmployee': {
      const both = (v: string | null) => ({ en: v ?? '', ar: v ?? '' })
      const r = await callInternal({
        method: 'POST',
        path: '/employees',
        cookie,
        body: {
          email: params.email,
          employeeNumber: params.employeeNumberNew,
          fullName: both(params.title),
          jobTitle: both(params.jobTitle),
          department: both(params.department),
          role: params.role ?? 'employee',
          joinedOn: dayKey(new Date()),
        },
      })
      if (!r.ok) {
        return r.error === 'emailTaken'
          ? fail('That email already has an account.', 'الإيميل هاد إله حساب أصلاً.')
          : r.error === 'employeeNumberTaken'
            ? fail('That employee number is already used.', 'الرقم الوظيفي مستعمل.')
            : fail('The account was not created.', 'الحساب ما انشأ.')
      }
      return {
        ok: true,
        message: L('The account is created.', 'انشأ الحساب.'),
        messageKey: null,
        messageParams: null,
        path: '/hr/employees',
      }
    }

    case 'updateEmployeeDetails': {
      const both = (v: string | null) => ({ en: v ?? '', ar: v ?? '' })
      const r = await callInternal({
        method: 'PATCH',
        path: `/employees/${need(params.targetId)}`,
        cookie,
        body: {
          ...(params.jobTitle ? { jobTitle: both(params.jobTitle) } : {}),
          ...(params.department ? { department: both(params.department) } : {}),
        },
      })
      if (!r.ok) return explain(r.error, 'The details were not changed.', 'البيانات ما انغيّرت.')
      return {
        ok: true,
        message: L('The details are updated.', 'انحدّثت البيانات.'),
        messageKey: null,
        messageParams: null,
        path: '/hr/employees',
      }
    }

    case 'setSalary': {
      const r = await callInternal({
        method: 'POST',
        path: `/payroll/salary/${need(params.targetId)}`,
        cookie,
        body: { basic: params.amount, effectiveFrom: params.startDate },
      })
      if (!r.ok) {
        return r.error === 'runAlreadyApproved'
          ? fail(
              'A payroll run covering that date is already approved, so it cannot change.',
              '\u0641\u064a \u062f\u0648\u0631\u0629 \u0631\u0648\u0627\u062a\u0628 \u0645\u0639\u062a\u0645\u062f\u0629 \u0628\u062a\u063a\u0637\u064a \u0647\u0627\u0644\u062a\u0627\u0631\u064a\u062e\u060c \u0641\u0645\u0627 \u0628\u062a\u0642\u062f\u0631 \u062a\u062a\u063a\u064a\u0651\u0631.',
            )
          : fail('The salary was not set.', '\u0627\u0644\u0631\u0627\u062a\u0628 \u0645\u0627 \u0627\u0646\u062d\u062f\u0651\u062f.')
      }
      return {
        ok: true,
        message: L('The salary is set.', '\u0627\u0646\u062d\u062f\u0651\u062f \u0627\u0644\u0631\u0627\u062a\u0628.'),
        messageKey: null,
        messageParams: null,
        path: '/hr/payroll',
      }
    }

    case 'runPayroll': {
      const now = new Date()
      const r = await callInternal({
        method: 'POST',
        path: '/payroll/runs',
        cookie,
        body: { year: now.getFullYear(), month: now.getMonth() + 1 },
      })
      if (!r.ok) {
        return r.error === 'runAlreadyApproved'
          ? fail('This month is already approved and cannot be recalculated.', 'هالشهر معتمد وما بينحسب من جديد.')
          : fail('The payroll could not be calculated.', 'ما قدرت أحسب الرواتب.')
      }
      return { ok: true, message: L('The payroll is calculated.', 'انحسبت الرواتب.'), messageKey: null, messageParams: null, path: '/hr/payroll' }
    }
  }
}
