import { BriefcaseBusiness, ShieldCheck, UserRound, UsersRound, type LucideIcon } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import type { TKey } from '@/features/i18n/dictionary'
import { useI18n } from '@/features/i18n/useI18n'

const scopes: { icon: LucideIcon; title: TKey; detail: TKey }[] = [
  { icon: ShieldCheck, title: 'adminPerms.adminScope', detail: 'adminPerms.adminScopeSub' },
  { icon: UsersRound, title: 'adminPerms.managerScope', detail: 'adminPerms.managerScopeSub' },
  { icon: UserRound, title: 'adminPerms.employeeScope', detail: 'adminPerms.employeeScopeSub' },
]

const policies: { icon: LucideIcon; role: TKey; policy: TKey }[] = [
  { icon: ShieldCheck, role: 'role.admin', policy: 'adminPerms.policyAdmin' },
  { icon: UsersRound, role: 'role.manager', policy: 'adminPerms.policyManager' },
  { icon: BriefcaseBusiness, role: 'role.hr', policy: 'adminPerms.policyHr' },
  { icon: UserRound, role: 'role.employee', policy: 'adminPerms.policyEmployee' },
]

const checks: { icon: LucideIcon; title: TKey; detail: TKey }[] = [
  { icon: UsersRound, title: 'adminPerms.qaRole', detail: 'adminPerms.qaRoleHint' },
  { icon: ShieldCheck, title: 'adminPerms.qaAccess', detail: 'adminPerms.qaAccessHint' },
  { icon: BriefcaseBusiness, title: 'adminPerms.qaAudit', detail: 'adminPerms.qaAuditHint' },
]

export function AdminPermissionsPage() {
  const { t } = useI18n()

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium uppercase tracking-[0.18em] text-brand">{t('section.admin')}</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight text-ink">{t('adminPerms.title')}</h2>
        </div>
        <Badge tone="success">{t('adminPerms.badge')}</Badge>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {scopes.map(({ icon: Icon, title, detail }) => (
          <Card key={title} title={t(title)} icon={Icon}>
            <p className="text-sm text-muted">{t(detail)}</p>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {checks.map(({ icon: Icon, title, detail }) => (
          <Card key={title} title={t(title)} icon={Icon}>
            <p className="text-sm text-muted">{t(detail)}</p>
          </Card>
        ))}
      </div>

      <Card title={t('adminPerms.policyTitle')} icon={ShieldCheck}>
        <div className="divide-y divide-line">
          {policies.map(({ icon: Icon, role, policy }) => (
            <div key={role} className="flex gap-3 py-4 first:pt-0 last:pb-0">
              <Icon className="mt-0.5 size-4 shrink-0 text-brand" aria-hidden="true" />
              <div>
                <h3 className="text-sm font-semibold text-ink">{t(role)}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted">{t(policy)}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}