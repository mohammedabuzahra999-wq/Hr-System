import { Hono } from 'hono'
import {
  copilotDeclinedSchema,
  copilotDoSchema,
  copilotFillSchema,
  copilotRequestSchema,
  copilotActionPlanSchema,
  type CopilotAnswer,
  type CopilotDoRequest,
  type CopilotActionPlan,
  type CopilotDeclinedRequest,
  type CopilotFillRequest,
  type CopilotRequest,
} from '@hr/shared'
import { executeIntent } from '../copilot/execute.js'
import { intentsFor, mayAsk } from '../copilot/intents.js'
import { continueTask, phraseAnswer, resolveAction, resolveQuestion } from '../copilot/resolve.js'
import { proposeAction, runAction } from '../copilot/perform.js'
import { recall, remember } from '../copilot/memory.js'
import {
  clear as clearTask,
  lastQuestion,
  pendingFor,
  remember as rememberTask,
  rememberQuestion,
} from '../copilot/conversation.js'
import { EMPTY_ACTION_PLAN, EMPTY_PLAN, lookUp } from '../copilot/phrasebook.js'
import { formFor, valuesFrom } from '../copilot/forms.js'
import { suggestFromApproved } from '../ai/retrieval.js'
import { mayDo } from '../copilot/actions.js'
import { dayKey } from '../domain/workdays.js'
import { buildReport } from '../reports/build.js'
import { buildEmployeeFile } from '../reports/employeeFile.js'
import { answerGuide, suggestionsFor } from '../guide/answer.js'
import { tourFor } from '../guide/tour.js'
import { eq } from 'drizzle-orm'
import { db } from '../db/client.js'
import { users } from '../db/schema.js'
import { narrate } from '../reports/narrate.js'
import { requireAuth, validateBody, type AppEnv } from '../middleware.js'
import { env } from '../env.js'
import { rateLimit } from '../rateLimit.js'

/**
 * Asking the HR system a question.
 *
 * Open to every signed-in role, because what differs between them is not
 * whether they may ask but which questions exist for them — and that is decided
 * by `INTENT_ROLES`, checked below, not by anything the model produced.
 *
 * The order of the steps is the security property, so it is worth reading in
 * order: classify, then check the role against the classification, then query.
 * Nothing touches the database before that check, and the check does not
 * consult the model.
 */
export const copilotRoutes = new Hono<AppEnv>()

copilotRoutes.use('*', requireAuth)

/**
 * Twenty questions an hour per person.
 *
 * Each one costs two model calls, and the ceiling is per account rather than
 * per address so that an office behind one address is not rationed collectively
 * — the opposite of the careers form, where the asker is anonymous and the
 * address is all there is.
 */
const askLimit = rateLimit({
  name: 'copilot',
  limit: 20,
  windowMs: 60 * 60 * 1000,
  keyExtra: (c) => c.get('user')?.id ?? null,
})

/** The questions this person can actually ask, for the suggestion chips. */
copilotRoutes.get('/intents', (c) =>
  c.json({
    intents: intentsFor(c.get('user').role),
    /** Questions worth offering on the screen they are on. */
    guide: suggestionsFor(c.get('user').role, c.req.query('path')),
  }),
)

/**
 * The fields of an instruction, and whatever is already known about them.
 *
 * Sent with a refusal so the panel can show boxes instead of asking for one
 * detail per message. It is an offer, not a redirection: the same refusal still
 * carries its sentence, and an action with nothing to fill in sends no boxes and
 * reads exactly as it did.
 */
async function boxes(plan: CopilotActionPlan, lang: 'en' | 'ar' = 'ar') {
  const fields = formFor(plan.action)
  if (!fields) return {}
  const values = valuesFrom(plan, fields)

  /*
   * Boxes nobody filled in, filled in from a role the company already wrote up.
   *
   * The complaint that produced this: leave the skills empty and the draft comes
   * back saying "not specified" for section after section \u2014 when there is an
   * approved description for very nearly the same role sitting in the library
   * with all of it written down. Refusing to look at it is not caution, it is
   * ignoring the evidence.
   *
   * Only ever into an empty box, and only from a near-identical role. The
   * document it came from is named beside it, so a suggestion that does not
   * belong is obvious before it is used rather than after it is published.
   */
  let suggested: Record<string, string> | undefined
  if (plan.action === 'generateJobDescription' && plan.title?.trim()) {
    const hit = await suggestFromApproved(plan.title.trim(), plan.department?.trim() ?? null)
    if (hit) {
      suggested = {}
      for (const box of fields) {
        if (values[box.field]) continue
        const found = hit.values[box.field]
        if (!found) continue
        const text = lang === 'ar' ? found.ar || found.en : found.en || found.ar
        if (!text.trim()) continue
        /*
         * A box that only accepts certain answers cannot be pre-filled with
         * prose. Education used to be free text and is now a level, so a
         * neighbouring role's "bachelor's in telecommunications engineering"
         * matches no option — it would leave an empty select wearing a note
         * saying where its value came from.
         */
        if (box.kind === 'choice' && !box.options?.some((o) => o.value === text)) continue
        values[box.field] = text
        suggested[box.field] = hit.from
      }
      if (Object.keys(suggested).length === 0) suggested = undefined
    }
  }

  return { form: fields, values, ...(suggested ? { suggested } : {}) }
}

copilotRoutes.post('/ask', askLimit, validateBody(copilotRequestSchema), async (c) => {
  const actor = c.get('user')
  const body = c.get('body') as CopilotRequest
  const { question } = body

  const refuse = (refusal: CopilotAnswer['refusal']): CopilotAnswer =>
    refuseAs(!env.AI_SHARE_DATA, refusal)

  /**
   * 0. Is this an answer to what was just asked?
   *
   * Checked before classifying, because "من الأحد" classified on its own is
   * nothing at all — and read against "which dates?" it is a date. The
   * assistant asked a question one message ago; the obvious thing to do with
   * the reply is read it as the reply.
   *
   * It can decline. Somebody who changes their mind mid-task and types
   * something else entirely falls through to the ordinary path, and the
   * half-finished instruction is dropped.
   */
  const waiting = pendingFor(actor.id)
  if (waiting) {
    const carried = await continueTask(question, waiting.asked, waiting.collected, dayKey(new Date()))

    /*
     * Turning the question down is still continuing.
     *
     * The same instruction goes through with this question added to what has
     * been declined, so the gap that produced it is not produced again. That is
     * the whole of the way out: one list, checked by the action that asked.
     */
    const declined = carried.continues
      ? waiting.declined
      : [...waiting.declined, ...waiting.asked.fields]
    const plan = carried.continues ? carried.plan : waiting.collected
    const goingAhead = carried.continues || (carried.skipped && waiting.asked.optional)

    if (goingAhead) {
      const proposed = await proposeAction(plan, actor, declined)
      /*
       * Enough to act on. A choice counts as finished too — its options each
       * carry their own parameters and are answered by pressing one, so there
       * is no further reply to wait for.
       */
      if (proposed.ok) {
        clearTask(actor.id)
        return c.json({
          answer: {
            intent: 'doAction' as const,
            sentence: 'choice' in proposed ? proposed.choice.question : { en: '', ar: '' },
            result:
              'choice' in proposed
                ? ({ kind: 'choose' as const, choice: proposed.choice })
                : ({ kind: 'confirm' as const, proposal: proposed.proposal }),
            periodLabel: null,
            refusal: null,
            sharingOff: false,
          } satisfies CopilotAnswer,
        })
      }
      /* Still short of something: ask for the next piece and stay in the task. */
      if (proposed.missing?.fields.length) {
        rememberTask(actor.id, {
          action: plan.action,
          collected: plan,
          asked: proposed.missing,
          declined,
        })
        return c.json({
          answer: { ...refuse('unclear'), intent: 'doAction' as const },
          error: 'action.unclear',
          action: plan.action,
          /*
           * They have just answered something, so the next question can say so.
           *
           * The wording differs between the two cases and the difference is not
           * cosmetic: "almost, I still need X" told somebody who had only just
           * typed their first sentence that they had nearly got it right.
           */
          continuing: true,
          ...(await boxes(plan, body.lang)),
          missing: { en: proposed.missing.en, ar: proposed.missing.ar },
          /* So the wording can ask rather than demand. */
          optional: proposed.missing.optional,
        })
      }

      /*
       * The answer was understood and the thing still cannot be done — there
       * is no pending request to withdraw, the day is already recorded. That
       * reason is the answer. Re-reading “annual” as a fresh sentence would
       * replace it with “I did not understand”, which is not what happened.
       */
      clearTask(actor.id)
      return c.json({
        answer: {
          ...refuse(proposed.reason === 'notPermitted' ? 'notPermitted' : 'unclear'),
          intent: 'doAction' as const,
        },
        error: `action.${proposed.reason}`,
        detail: proposed.detail ?? null,
        /*
         * Sent even here, because a fieldless gap is where the reason lives —
         * “there is already a vacancy for that role” is the answer, and dropping
         * it would leave only “I did not understand”.
         */
        missing: proposed.missing ? { en: proposed.missing.en, ar: proposed.missing.ar } : null,
      })
    }
    /*
     * Called off. This ends the turn rather than falling through, because a
     * withdrawal read as a fresh sentence becomes an instruction: “خلص لا
     * تعمل اشي” classified on its own resolved to checkOut, so calling a
     * leave request off offered to clock the person out. Nothing is proposed.
     */
    if (!carried.continues && (carried.abandoned || carried.skipped)) {
      clearTask(actor.id)
      return c.json({
        answer: {
          intent: 'doAction' as const,
          /*
           * A skip only reaches here when the question it answered was one that
           * could not be skipped — the dates of a leave request, the role of a
           * job description. Saying so is better than carrying out something
           * half-specified, and better than the silence of falling through.
           */
          sentence: carried.abandoned
            ? {
                en: 'Dropped it. Tell me when you want something else.',
                ar: 'تمام، تركتها. قلّي لما تحتاج شي تاني.',
              }
            : {
                en: `I cannot go ahead without ${waiting.asked.en}. Say it and I will, or tell me to drop it.`,
                ar: `ما بقدر أكمّل بلا ${waiting.asked.ar}. قلّي إياه وبكمّل، أو قلّي أتركها.`,
              },
          result: { kind: 'none' as const },
          periodLabel: null,
          refusal: null,
          sharingOff: !env.AI_SHARE_DATA,
        } satisfies CopilotAnswer,
      })
    }

    /* Not an answer at all — the half-finished instruction is dropped. */
    clearTask(actor.id)
  }

  /* 1. Classify. The model sees the question and the list of intents for this
        role, and nothing else. No data has been read at this point. */
  const booked = lookUp(question, actor.role)
  const resolved = booked
    ? /**
       * Sentences that do not need classifying.
       *
       * A known phrasing routes by lookup, with no model call at all — same
       * words, same answer, every time. This is the fix for the variance the
       * measurements showed: the paths people repeat stop being a judgement
       * call, and the model is left with the sentences nobody has named, which
       * is what it is actually good at.
       *
       * It grants nothing. `lookUp` already returned null for anything this
       * role may not ask or do, and every gate below still runs.
       */
      ({
        ok: true as const,
        plan: {
          ...EMPTY_PLAN,
          intent: booked.kind === 'question' ? booked.intent : ('doAction' as const),
        },
      })
    : /*
         * The previous question goes in with this one.
         *
         * Only when the phrasebook did not already settle it, which is the
         * common case for a follow-up: nobody lists "وقبلو" in a phrasebook,
         * because it means nothing until you know what came before.
         */
      await resolveQuestion(question, actor.role, lastQuestion(actor.id))
  if (!resolved.ok) {
    return c.json({ answer: refuse('unclear'), error: resolved.reason }, 200)
  }

  const plan = resolved.plan

  /*
   * A follow-up that changed nothing is not a follow-up.
   *
   * Carrying the previous intent over is only worth doing if the new message
   * moved something \u2014 the period, the department, the person. When it comes back
   * identical, one of two things happened: the message asked for something the
   * plan cannot express ("\u0648\u0642\u0628\u0644\u0648" \u2014 there is no value for two months back),
   * or the intent was carried and the change was missed. Either way the honest
   * result is the one from before any of this existed: say it was not understood.
   *
   * The alternative is what was measured while building it: "\u0648\u0634\u0648 \u0639\u0646 \u0627\u0644\u0634\u0647\u0631
   * \u0627\u0644\u064a \u0642\u0628\u0644" answered with this month's figures under a sentence about last
   * month. A refusal costs a rephrase; that costs somebody trusting a number.
   */
  const carriedFrom = booked ? null : lastQuestion(actor.id)
  if (carriedFrom && plan.intent === carriedFrom.intent) {
    const moved =
      plan.period !== carriedFrom.period ||
      plan.department !== carriedFrom.department ||
      plan.personName !== carriedFrom.personName ||
      plan.employeeNumber !== carriedFrom.employeeNumber ||
      plan.rankBy !== carriedFrom.rankBy
    if (!moved) {
      return c.json({ answer: refuse('unclear'), error: 'copilot.followUpUnchanged' }, 200)
    }
  }

  /** Set when the vague-instruction retry below already worked out the action. */
  let reresolved: CopilotActionPlan | null = null

  /**
   * What this sentence meant last time somebody accepted the answer.
   *
   * Applied over the model's choice, not instead of it: the model still runs
   * and still fills in the specifics, and only the routing is pinned. That is
   * the part that was unstable — the same instruction resolving two ways on
   * consecutive tries — and the part a person has already vouched for.
   *
   * It grants nothing. `mayAsk` and every check after it run unchanged, so a
   * routing remembered from an administrator gives an employee the refusal
   * they would have got anyway.
   */
  /*
   * Skipped when the phrasebook already settled it.
   *
   * The two disagreed and the memory won, which was the wrong way round: the
   * phrasebook is written deliberately, the memory is inferred from what
   * happened. "سجل حضوري" is in the book as an instruction, misrouted to
   * `myAttendance` eight times before the book existed, and was pinned there
   * — a wrong reading made permanent by being repeated.
   */
  const known = booked ? null : await recall(question, actor.role)
  if (known?.kind === 'question' && known.intent && mayAsk(actor.role, known.intent)) {
    plan.intent = known.intent
  } else if (known?.kind === 'instruction') {
    plan.intent = 'doAction'
  }

  /**
   * A second chance for instructions the first pass called vague.
   *
   * The intent classifier decides question-or-instruction, and it is allowed to
   * say "too vague". That verdict is right for a question and wrong for a
   * command: "add something to the calendar" is not an unanswerable question,
   * it is an instruction with a detail missing, and the action layer can say
   * which detail. Three attempts at wording the prompt out of this did not
   * hold — so it is settled in code instead of asked for in English.
   *
   * Only on the `unclear` path, so it costs a model call exactly where the
   * alternative was a refusal that helped nobody. `notHrData` and
   * `notPermitted` are decisions, not doubt, and are not retried.
   */
  if (plan.intent === 'outOfScope') {
    if (plan.refusalReason !== 'unclear') {
      /* Counted, because a refusal is a request for something that does not exist yet. */
      void remember(question, actor.role, { kind: 'question', intent: 'outOfScope' }, {
        kind: 'refused',
        reason: plan.refusalReason ?? 'unclear',
      })
      return c.json({ answer: refuse(plan.refusalReason ?? 'unclear') })
    }
    const retry = await resolveAction(question, actor.role, dayKey(new Date()))
    if (!retry.ok || retry.plan.refusalReason === 'notPermitted') {
      return c.json({ answer: refuse(retry.ok ? 'notPermitted' : 'unclear') })
    }
    /*
     * A chosen action with a detail missing is not a dead end. It goes on to be
     * described, and the description is what names the missing piece — "I still
     * need a name for the event" beats "I did not understand", which is the same
     * refusal with the useful half removed.
     */
    plan.intent = 'doAction'
    reresolved = retry.plan
  }

  /* 2. The check that actually enforces anything.
        The model chose; this decides. A model that picked `orgAttendance` for
        an employee — through confusion, or because the question asked it to —
        stops here, and stops before a single row is read. */
  if (!mayAsk(actor.role, plan.intent)) {
    console.warn(`[copilot] ${actor.role} was routed to ${plan.intent} and refused`)
    return c.json({ answer: refuse('notPermitted') })
  }

  /**
   * Saying hello back, and saying what this can do.
   *
   * Answered here rather than by the model, for three reasons: a greeting has
   * no facts in it to get wrong, a hand-written sentence costs nothing and
   * cannot drift, and the useful half of the reply is the list of questions
   * this person can actually ask — which the panel already knows and shows.
   *
   * "السلام عليكم" is answered with its own response. Returning a generic
   * "hello" to it is the kind of small wrongness that tells an Arabic speaker
   * the product was translated rather than written.
   */
  if (plan.intent === 'greeting') {
    // with or without the article, and however they spaced it
    const salaam = /(ال)?سلام\s*عليكم/.test(question)
    return c.json({
      answer: {
        intent: plan.intent,
        sentence: {
          en: 'Hello. Ask me about what is in the system, or how to do something in it — here is what you can ask me:',
          ar: salaam
            ? 'وعليكم السلام ورحمة الله. اسألني عن اللي بالنظام، أو كيف تعمل إشي فيه — هاي اللي بتقدر تسألني عنه:'
            : 'أهلاً وسهلاً. اسألني عن اللي بالنظام، أو كيف تعمل إشي فيه — هاي اللي بتقدر تسألني عنه:',
        },
        result: { kind: 'none' },
        periodLabel: null,
        refusal: null,
        sharingOff: false,
      } satisfies CopilotAnswer,
    })
  }

  /**
   * An instruction rather than a question.
   *
   * Three steps, and the order is again the security property: work out which
   * action, check that this role may take it, then describe it and stop. The
   * description goes back to the person and nothing has happened — the write
   * waits for `/do` below, which re-checks everything before it runs.
   */
  if (plan.intent === 'doAction') {
    let wanted = reresolved
    /* A looked-up instruction skips the second model call as well. */
    if (!wanted && booked?.kind === 'action') {
      wanted = { ...EMPTY_ACTION_PLAN, action: booked.action, screen: booked.screen ?? null }
    }
    if (!wanted) {
      const resolvedAction = await resolveAction(question, actor.role, dayKey(new Date()))
      if (!resolvedAction.ok) return c.json({ answer: refuse('unclear'), error: resolvedAction.reason }, 200)
      wanted = resolvedAction.plan
    }
    /* The remembered action wins; its parameters are still this morning's. */
    if (known?.kind === 'instruction' && known.action) wanted.action = known.action
    if (wanted.refusalReason === 'notPermitted') return c.json({ answer: refuse('notPermitted') })

    const proposed = await proposeAction(wanted, actor)
    if (!proposed.ok) {
      console.warn(`[copilot] ${actor.role} asked for ${wanted.action}: ${proposed.reason}`)
      void remember(question, actor.role, { kind: 'instruction', action: wanted.action }, {
        kind: 'refused',
        reason: proposed.reason,
      })
      /*
       * A missing detail opens a task rather than ending the turn. The
       * assistant has just asked a question, and the next message is almost
       * always the answer to it.
       */
      if (proposed.missing?.fields.length) {
        rememberTask(actor.id, {
          action: wanted.action,
          collected: wanted,
          asked: proposed.missing,
          /* Nothing has been asked yet, so nothing has been turned down yet. */
          declined: [],
        })
      }
      return c.json({
        answer: {
          ...refuse(proposed.reason === 'notPermitted' ? 'notPermitted' : 'unclear'),
          intent: 'doAction' as const,
        },
        error: `action.${proposed.reason}`,
        /**
         * What it decided to do, when it is still willing to do it.
         *
         * A refusal used to name only its reason, which made two different
         * outcomes look identical from outside: routed to the wrong action, and
         * routed to the right one but short of a detail. The first is a defect
         * and the second is a conversation, and telling them apart is the
         * difference between measuring routing and guessing at it.
         *
         * Withheld when the refusal is one of permission. Somebody who may not
         * run payroll has no use for the name of the thing they may not do, and
         * a refusal that reports an action reads as one that took it.
         */
        action: proposed.reason === 'notPermitted' ? null : wanted.action,
        /** Nothing has been answered yet: this is the first thing asked. */
        continuing: false,
        ...(await boxes(wanted, body.lang)),
        /** The names that matched, so "which one?" is answerable. */
        detail: proposed.detail ?? null,
        /** Or the piece it needed and did not get, named in both languages. */
        missing: proposed.missing ? { en: proposed.missing.en, ar: proposed.missing.ar } : null,
        optional: proposed.missing?.optional ?? false,
      })
    }

    /*
     * Either one thing to confirm, or several to choose between. The second
     * case is what "cancel my request" means when two are pending: asking is
     * the honest answer, and picking the most recent is the one that eventually
     * withdraws the wrong one without anybody noticing.
     */
    const result =
      'choice' in proposed
        ? ({ kind: 'choose' as const, choice: proposed.choice })
        : ({ kind: 'confirm' as const, proposal: proposed.proposal })

    return c.json({
      answer: {
        intent: plan.intent,
        sentence: 'choice' in proposed ? proposed.choice.question : { en: '', ar: '' },
        result,
        periodLabel: null,
        refusal: null,
        sharingOff: false,
      } satisfies CopilotAnswer,
    })
  }

  /**
   * How to use the system. Grounded in the guide entries, not in the model's
   * idea of what an HR system usually looks like — see `guide/answer.ts`.
   */
  if (plan.intent === 'howDoI') {
    const guide = await answerGuide(question, actor.role, body.path)
    if (!guide) return c.json({ answer: refuse('unclear') })
    return c.json({
      answer: {
        intent: plan.intent,
        sentence: guide.explanation,
        result: { kind: 'guide', steps: guide.steps, links: guide.links },
        periodLabel: null,
        refusal: null,
        sharingOff: false,
      } satisfies CopilotAnswer,
    })
  }

  /**
   * One person's file, which is a report about somebody rather than about a
   * period. Returning null means either no such employee, or one this asker may
   * not see — and the two are deliberately the same answer, because a different
   * one would confirm that a person exists.
   */
  if (plan.intent === 'employeeFile') {
    const built = await buildEmployeeFile(
      { employeeNumber: plan.employeeNumber, personName: plan.personName },
      actor,
    )
    if (!built) return c.json({ answer: refuse('noData') })
    const prose = await narrate(built)
    return c.json({
      answer: {
        intent: plan.intent,
        sentence: { en: '', ar: '' },
        result: { kind: 'report', report: { ...built, ...prose } },
        periodLabel: built.period,
        refusal: null,
        sharingOff: !env.AI_SHARE_DATA,
      } satisfies CopilotAnswer,
    })
  }

  /**
   * A report takes its own path: it is a document rather than an answer, its
   * figures come from `buildReport`, and the prose is written afterwards from
   * those figures by a step that can reach nothing else.
   */
  if (plan.intent === 'generateReport' || plan.intent === 'myReport') {
    /*
     * Whose report it is comes from the intent, which the gate above already
     * checked, and not from a field. `myReport` is open to everybody because it
     * can only ever cover the person asking; `generateReport` is manager and up
     * because it covers other people. One flag, decided here, passed to a
     * function that reads it before it reads anything else.
     */
    const self = plan.intent === 'myReport'
    const built = await buildReport(plan.reportType ?? 'attendance', actor, {
      period: plan.period,
      department: plan.department,
      self,
    })
    const prose = await narrate(built)
    const report = { ...built, ...prose }
    return c.json({
      answer: {
        intent: plan.intent,
        sentence: { en: '', ar: '' },
        result: { kind: 'report' as const, report },
        periodLabel: report.period,
        refusal: null,
        sharingOff: !env.AI_SHARE_DATA,
      } satisfies CopilotAnswer,
    })
  }

  /*
   * A question that reached a query was routed correctly enough to answer, and
   * the person saw the answer. That is the acceptance — there is no button to
   * press on a figure, so the absence of a refusal is the signal available.
   */
  /*
   * Not recorded when the phrasebook knows it: the book is already the answer,
   * and a memory beside it can only ever agree or contradict.
   *
   * The signal is weak even so. For a question, "accepted" means it reached a
   * query without being refused — not that it answered what was asked. A
   * question that lands on a different but valid intent still returns
   * something, and is recorded as a success. It is the best signal available
   * without asking people to rate answers, and it is worth knowing that it
   * over-counts.
   */
  if (!booked) {
    void remember(question, actor.role, { kind: 'question', intent: plan.intent }, { kind: 'accepted' })
  }

  /* 3. Only now, a query — written by hand and scoped in SQL to this person. */
  const { result, periodLabel, empty } = await executeIntent(plan, actor)

  if (empty) {
    return c.json({
      answer: {
        intent: plan.intent,
        sentence: { en: '', ar: '' },
        result,
        periodLabel,
        refusal: 'noData' as const,
        sharingOff: !env.AI_SHARE_DATA,
      },
    })
  }

  /* 4. A sentence describing what came back. If the model is unavailable the
        figures still render — the sentence is the optional part. */
  const sentence = (await phraseAnswer(question, plan.intent, result)) ?? { en: '', ar: '' }

  const answer: CopilotAnswer = {
    intent: plan.intent,
    sentence,
    result,
    periodLabel,
    refusal: null,
    sharingOff: !env.AI_SHARE_DATA,
  }

  /*
   * Recorded only here, at the one exit where a question was actually answered.
   *
   * Not at the top, and not on a refusal: a question that was refused or found
   * nothing is not something to carry forward, because "and last month?" against
   * it would refine a question that never worked in the first place.
   */
  rememberQuestion(actor.id, plan)
  return c.json({ answer })
})

/**
 * The introductory tour.
 *
 * On `/auth/me` rather than here would have been tidier, but the tour belongs
 * with the guidance it is built from — and a route that returns it separately
 * means the app can ask for it once at startup and never again.
 */
copilotRoutes.get('/tour', async (c) => {
  const actor = c.get('user')
  const [row] = await db
    .select({ at: users.tourCompletedAt })
    .from(users)
    .where(eq(users.id, actor.id))
    .limit(1)
  return c.json({ tour: tourFor(actor.role, row?.at ?? null) })
})

/**
 * Finishing, or skipping — recorded the same way.
 *
 * Somebody who dismissed the tour has made a decision. Offering it again at
 * every login would be the software ignoring them; they can start it again
 * themselves by asking the assistant.
 */
copilotRoutes.post('/tour/done', async (c) => {
  const actor = c.get('user')
  await db.update(users).set({ tourCompletedAt: new Date() }).where(eq(users.id, actor.id))
  return c.json({ ok: true })
})

/** Starting it again on purpose, which clears the record rather than faking it. */
copilotRoutes.post('/tour/restart', async (c) => {
  const actor = c.get('user')
  await db.update(users).set({ tourCompletedAt: null }).where(eq(users.id, actor.id))
  const [row] = await db.select({ at: users.tourCompletedAt }).from(users).where(eq(users.id, actor.id)).limit(1)
  return c.json({ tour: tourFor(actor.role, row?.at ?? null) })
})

/**
 * Carrying out what was confirmed.
 *
 * Deliberately a separate endpoint from `/ask`, and deliberately not trusting
 * anything about the proposal it is answering. The confirmation card is a
 * safeguard for the person, not a token: this re-reads the role, re-resolves
 * the record, and calls the same route a browser would, which performs its own
 * permission check on the way in. A client that fabricated a proposal and
 * posted it here gets exactly what it would get by calling that route directly,
 * which is a refusal.
 *
 * Rate-limited harder than asking. A question costs two model calls; this
 * changes records, and twenty of those an hour is already generous for
 * something a person is confirming one press at a time.
 */
/**
 * A refusal, with nothing else attached.
 *
 * Lifted out of the `/ask` handler when a second handler needed the same shape.
 * Two copies of this would be two places for the sharing flag to be forgotten.
 */
function refuseAs(sharingOff: boolean, refusal: CopilotAnswer['refusal']): CopilotAnswer {
  return {
    intent: 'outOfScope',
    sentence: { en: '', ar: '' },
    result: { kind: 'none' },
    periodLabel: null,
    refusal,
    sharingOff,
  }
}

const doLimit = rateLimit({
  name: 'copilot-do',
  limit: 20,
  windowMs: 60 * 60 * 1000,
  keyExtra: (c) => c.get('user')?.id ?? null,
})

copilotRoutes.post('/do', doLimit, validateBody(copilotDoSchema), async (c) => {
  const actor = c.get('user')
  const body = c.get('body') as CopilotDoRequest
  const { params } = body

  /*
   * The asker's own session, forwarded. The action runs as them, so it can do
   * what they could do by hand and nothing more.
   */
  const cookie = c.req.header('cookie') ?? ''
  const outcome = await runAction(params, actor, cookie)

  console.log(`[copilot] ${actor.role} ${params.action}: ${outcome.ok ? 'done' : 'refused'}`)

  /*
   * Learned only on success. A person confirmed it AND the backend carried it
   * out — anything less is not evidence the sentence was understood. A failure
   * here is recorded as a refusal instead, since the routing may have been the
   * reason it could not run.
   */
  if (body.question) {
    void remember(
      body.question,
      actor.role,
      { kind: 'instruction', action: params.action },
      outcome.ok ? { kind: 'accepted' } : { kind: 'refused', reason: outcome.messageKey ?? 'failed' },
    )
  }

  return c.json({
    answer: {
      intent: 'doAction' as const,
      sentence: outcome.message,
      result: { kind: 'done' as const, outcome },
      periodLabel: null,
      refusal: null,
      sharingOff: false,
    } satisfies CopilotAnswer,
  })
})

/**
 * A filled-in form, turned into the same proposal a sentence would produce.
 *
 * There is no model call anywhere in this handler, and that is the point of it:
 * a form has already answered the question a classifier exists to answer, so
 * running one would be spending latency and money to re-derive what was typed
 * into labelled boxes. It is also why this is deterministic where `/ask` is not.
 *
 * What it does NOT skip is any check. The plan it builds goes through
 * `proposeAction` exactly as a spoken one does, so the gap checks, the name
 * resolution and the permission gate all run, and confirmation still happens
 * afterwards through `/do`. The form decides what is asked for, never what is
 * allowed.
 */
copilotRoutes.post('/fill', doLimit, validateBody(copilotFillSchema), async (c) => {
  const actor = c.get('user')
  const { action, values } = c.get('body') as CopilotFillRequest

  /*
   * Refused here as well as inside `proposeAction`.
   *
   * Not redundancy for its own sake: this endpoint takes an action name straight
   * from the client, which is the one place in the assistant where that happens.
   * A caller naming something they may not do is turned away before a row is
   * read, and the refusal says nothing about whether the action exists.
   */
  if (!mayDo(actor.role, action)) {
    return c.json({ answer: refuseAs(!env.AI_SHARE_DATA, 'notPermitted') }, 200)
  }

  const fields = formFor(action)
  if (!fields) return c.json({ answer: refuseAs(!env.AI_SHARE_DATA, 'unclear') }, 200)

  /*
   * Only the fields this action declared, and nothing else in the body.
   *
   * The plan has twenty-odd fields and a form names a handful of them. Reading
   * the body wholesale would let a request for leave arrive carrying a
   * `personName`, which is somebody else's leave — so the declaration is the
   * whitelist, and anything not on it never reaches the plan.
   */
  const draft: Record<string, unknown> = { ...EMPTY_ACTION_PLAN, action }
  const declined: (keyof CopilotActionPlan)[] = []
  /* Boxes that have no field of their own, written out as labelled lines. */
  const folded: string[] = []

  for (const box of fields) {
    const typed = (values[box.field] ?? '').trim()
    if (!typed) {
      /* An optional box left empty is an answer, and is not asked about again. */
      if (!box.required && !box.into) declined.push(box.field as keyof CopilotActionPlan)
      continue
    }
    /* A choice may only be one of the values that were offered for it. */
    if (box.kind === 'choice' && !box.options?.some((o) => o.value === typed)) continue

    if (box.into) {
      /*
       * Labelled in English, which is what the generator reads its prompt in.
       * A choice is written as the value, not the Arabic the person picked, so
       * "senior" arrives as "senior".
       */
      folded.push(`${box.label.en}: ${typed}`)
      continue
    }
    draft[box.field] = typed
  }

  if (folded.length) {
    const existing = typeof draft.text === 'string' && draft.text ? `${draft.text}\n` : ''
    draft.text = `${existing}${folded.join('\n')}`
  } else if (fields.some((f) => f.into)) {
    /* Every composed box was left empty, so the brief was declined as a whole. */
    declined.push('text')
  }

  const parsed = copilotActionPlanSchema.safeParse(draft)
  if (!parsed.success) return c.json({ answer: refuseAs(!env.AI_SHARE_DATA, 'unclear') }, 200)
  const plan = parsed.data

  const proposed = await proposeAction(plan, actor, declined)
  if (!proposed.ok) {
    return c.json({
      answer: { ...refuseAs(!env.AI_SHARE_DATA, proposed.reason === 'notPermitted' ? 'notPermitted' : 'unclear'), intent: 'doAction' as const },
      error: `action.${proposed.reason}`,
      action: proposed.reason === 'notPermitted' ? null : action,
      detail: proposed.detail ?? null,
      /* The boxes again, holding what was typed, with the problem named. */
      ...(await boxes(plan)),
      missing: proposed.missing ? { en: proposed.missing.en, ar: proposed.missing.ar } : null,
      optional: proposed.missing?.optional ?? false,
      continuing: true,
    })
  }

  return c.json({
    answer: {
      intent: 'doAction' as const,
      sentence: 'choice' in proposed ? proposed.choice.question : { en: '', ar: '' },
      result:
        'choice' in proposed
          ? ({ kind: 'choose' as const, choice: proposed.choice })
          : ({ kind: 'confirm' as const, proposal: proposed.proposal }),
      periodLabel: null,
      refusal: null,
      sharingOff: !env.AI_SHARE_DATA,
    } satisfies CopilotAnswer,
  })
})

/**
 * Somebody read the proposal and said no.
 *
 * The most valuable signal the assistant gets, and the only one it cannot
 * infer: a person who understood what was about to happen decided it was not
 * what they asked for. One of these stops the routing being reused, which is
 * the point — a wrong reading that keeps being confidently repeated is worse
 * than one that was never learned.
 *
 * Fire-and-forget from the client's side; it returns ok whatever happens,
 * because a person cancelling something must never see an error for it.
 */
copilotRoutes.post('/declined', validateBody(copilotDeclinedSchema), async (c) => {
  const actor = c.get('user')
  const { question, action } = c.get('body') as CopilotDeclinedRequest
  await remember(question, actor.role, { kind: 'instruction', action }, { kind: 'rejected' })
  return c.json({ ok: true })
})
