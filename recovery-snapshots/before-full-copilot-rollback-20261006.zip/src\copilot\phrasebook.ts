import type { CopilotAction, CopilotIntent, Role } from '@hr/shared'
import { mayAsk } from './intents.js'
import { mayDo } from './actions.js'
import type { CopilotActionPlan, CopilotPlan } from '@hr/shared'

/**
 * Sentences whose meaning is not in question.
 *
 * Classification is a model call, and a model call is not deterministic — the
 * same instruction has been measured resolving three different ways across
 * three runs of the same thirty-seven cases. Three attempts at fixing that by
 * rewording the prompt made it worse rather than better, which is the usual
 * result of arguing with weather.
 *
 * So the common sentences stop being classified. "كم رصيد اجازاتي" has one
 * meaning, it has had that meaning every time anybody has typed it, and there
 * is nothing for a model to weigh up. Matching it here is a lookup: same input,
 * same output, no call, no latency, no cost, no variance.
 *
 * The model still handles everything else, which is most of what people
 * actually type — this covers the paths that repeat, not the language. Its job
 * changes from "route every sentence" to "route the ones nobody has named",
 * and it is much better at the second.
 *
 * Two things this is NOT:
 *
 *  - **Not a permission bypass.** A match still goes through `mayAsk` or
 *    `mayDo`. An employee typing a manager's phrasing gets the manager's
 *    refusal, not the manager's answer.
 *  - **Not a parameter shortcut.** Only phrasings with no specifics in them
 *    are listed. "بدي اجازة من 5 لـ 6" carries dates that change every time it
 *    is said, so it is not here; "بدي اجازة" is, and the dates are still
 *    worked out by the model afterwards.
 */

/** The form a sentence is matched on — the same folding the titles use. */
export function fold(text: string): string {
  return text
    .trim()
    .toLowerCase()
    .replace(/[ً-ْ]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة(\s|$)/g, 'ه$1')
    .replace(/[؟?!.,،]/g, '')
    .replace(/\s+/g, ' ')
}

type Known =
  | { kind: 'question'; intent: CopilotIntent }
  /** `screen` is set only by the navigation prefix, which carries its target. */
  | { kind: 'action'; action: CopilotAction; screen?: string }

const question = (intent: CopilotIntent, ...phrases: string[]) =>
  phrases.map((p) => [fold(p), { kind: 'question' as const, intent }] as const)

const action = (act: CopilotAction, ...phrases: string[]) =>
  phrases.map((p) => [fold(p), { kind: 'action' as const, action: act }] as const)

/**
 * Written out rather than generated from the suggestion chips.
 *
 * The chips are one phrasing each, and one phrasing is not how people type —
 * the same question arrives as "كم رصيد اجازاتي", "كم باقي من إجازتي" and
 * "how much leave do I have". All three belong to the same answer and none of
 * them is worth a model call.
 */
const ENTRIES: (readonly [string, Known])[] = [
  /* ---------- about yourself ---------- */
  ...question(
    'myLeaveBalance',
    'كم رصيد اجازاتي', 'كم باقي من اجازتي', 'كم اجازة باقي عندي', 'رصيد اجازاتي',
    'how much leave do i have', 'my leave balance', 'leave balance',
    'how many leave days do i have left', 'how many days off do i have', 'how much annual leave is left',
  ),
  ...question(
    'myPayslips',
    'كم راتبي', 'شو راتبي', 'اعرضلي كشوف رواتبي', 'كشف راتبي', 'رواتبي',
    'what do i earn', 'my salary', 'my payslips', 'how much do i earn',
    'i want to see my payslip', 'show me my payslip', 'where is my payslip',
  ),
  ...question(
    'myAttendance',
    'كيف كان حضوري', 'كيف كان حضوري هالشهر', 'حضوري هالشهر', 'كم يوم حضرت',
    'my attendance', 'how was my attendance',
    'show my attendance for last month', 'how many days did i attend', 'my attendance this month',
  ),
  ...question(
    'myRequests',
    'شو وضع طلباتي', 'وين وصلت طلباتي', 'طلباتي',
    'my requests', 'status of my requests',
    'what happened to the request i sent', 'where is my request', 'did my request get approved',
  ),

  /* ---------- a manager's own people ---------- */
  ...question('teamPresentNow', 'مين من فريقي حاضر', 'مين من فريقي حاضر هلق', 'who on my team is in'),
  ...question('teamOnLeave', 'مين من فريقي باجازة', 'مين باجازة من فريقي', 'who on my team is on leave'),
  ...question('teamPendingApprovals', 'شو الطلبات المعلقه عندي', 'الطلبات المعلقه', 'pending approvals'),
  ...question('teamRoster', 'مين بيشتغل تحتي', 'مين بفريقي', 'my team', 'who reports to me'),

  /* ---------- the organisation ---------- */
  ...question('headcount', 'كم عدد الموظفين', 'كم موظف عنا', 'عدد الموظفين', 'headcount', 'how many employees'),
  ...question('departmentBreakdown', 'وزعهم حسب الاقسام', 'الموظفين حسب القسم', 'breakdown by department'),
  ...question('orgAttendance', 'كيف الحضور على مستوى الشركه', 'حضور الشركه', 'company attendance'),
  ...question('whoIsPresentNow', 'مين موجود بالنظام هلق', 'مين حاضر هلق', 'who is in right now'),
  ...question('attendanceRanking', 'مين الاكثر حضورا', 'مين الاكثر حضورا هالشهر', 'who attends most'),
  ...question('recruitmentSummary', 'كيف ماشي التوظيف', 'وضع التوظيف', 'how is recruitment going'),
  ...question('listApplications', 'مين قدم عالوظائف', 'مين قدم', 'who has applied'),

  /* ---------- instructions with nothing variable in them ---------- */
  ...action('checkIn', 'سجل حضوري', 'سجلي حضور', 'سجل لي حضور', 'check me in', 'check in'),
  ...action('checkOut', 'سجل مغادرتي', 'سجلي مغادره', 'سجل لي مغادره', 'خلصت دوامي', 'check me out', 'check out'),
  ...action('cancelRequest', 'الغي طلبي', 'اسحب طلبي', 'cancel my request'),
  ...action('remindCheckout', 'ذكر اللي ما سجلوا مغادره', 'remind everyone to check out'),
  ...action('runPayroll', 'شغل رواتب هالشهر', 'احسب الرواتب', 'run payroll'),
  ...action('signOut', 'سجل خروج من النظام', 'اطلعني من النظام', 'خروج', 'log me out', 'sign out'),
]

const BOOK = new Map<string, Known>(ENTRIES)

/**
 * What this sentence means, when it is one nobody needs to think about.
 *
 * Returns null for anything unlisted, which is the model's job. Returns null
 * too when the person may not ask or do it — so a match never widens what
 * somebody can reach, it only settles what their words meant.
 */
export function lookUp(text: string, role: Role): Known | null {
  const folded = fold(text)

  /**
   * "Take me to …" is navigation whatever follows it.
   *
   * The screen name varies, so the sentence cannot be listed — but the verb
   * does not, and the verb is the whole decision. Both measured navigation
   * failures were this phrasing losing to "how do I", which a prefix settles
   * without a model and without listing every screen.
   */
  const NAVIGATES = ['وديني علي ', 'وديني ع', 'افتحلي ', 'افتح ', 'take me to ', 'go to ', 'open the ']
  const verb = NAVIGATES.find((v) => folded.startsWith(v))
  if (verb) {
    const screen = folded.slice(verb.length).trim()
    /* "ودّيني" with nothing after it names no screen; the model can have that one. */
    if (!screen) return null
    return mayDo(role, 'openScreen') ? { kind: 'action', action: 'openScreen', screen } : null
  }

  const known = BOOK.get(folded)
  if (!known) return null
  if (known.kind === 'question') return mayAsk(role, known.intent) ? known : null
  return mayDo(role, known.action) ? known : null
}

/** For the check that keeps this honest. */
export const PHRASEBOOK_ENTRIES = ENTRIES

/**
 * A plan with nothing filled in.
 *
 * A looked-up sentence has no parameters by construction — anything with a
 * date or a name in it is not in the book — so the plan it produces is the
 * intent and nothing else.
 */
export const EMPTY_PLAN: CopilotPlan = {
  intent: 'outOfScope',
  period: null,
  department: null,
  personName: null,
  employeeNumber: null,
  rankBy: null,
  reportType: null,
  refusalReason: null,
}

/** The same, for an instruction. */
export const EMPTY_ACTION_PLAN: CopilotActionPlan = {
  action: 'checkIn',
  leaveKind: null,
  startDate: null,
  endDate: null,
  documentKind: null,
  text: null,
  title: null,
  personName: null,
  employeeNumber: null,
  decision: null,
  stage: null,
  role: null,
  email: null,
  location: null,
  language: null,
  screen: null,
  employmentType: null,
  employeeNumberNew: null,
  jobTitle: null,
  department: null,
  amount: null,
  refusalReason: null,
}
