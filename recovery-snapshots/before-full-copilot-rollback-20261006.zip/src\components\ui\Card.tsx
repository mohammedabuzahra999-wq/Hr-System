import type { ReactNode } from 'react'
import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/cn'

interface CardProps {
  title?: string
  icon?: LucideIcon
  action?: ReactNode
  className?: string
  children: ReactNode
}

export function Card({ title, icon: Icon, action, className, children }: CardProps) {
  return (
    <section
      className={cn(
        'group flex flex-col rounded-[24px] border border-line bg-surface/95 shadow-[0_12px_35px_rgba(15,23,42,0.04)] backdrop-blur-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_18px_45px_rgba(29,78,216,0.08)]',
        className,
      )}
    >
      {title && (
        <header className="flex items-center gap-2.5 border-b border-line/80 px-5 py-3.5">
          {Icon && (
            <span className="grid size-8 place-items-center rounded-lg bg-brand-50 text-brand shadow-inner shadow-brand/5">
              <Icon className="size-4" aria-hidden="true" />
            </span>
          )}
          <h2 className="text-sm font-semibold text-ink">{title}</h2>
          {action && <div className="ms-auto">{action}</div>}
        </header>
      )}
      <div className="flex flex-1 flex-col p-5">{children}</div>
    </section>
  )
}
