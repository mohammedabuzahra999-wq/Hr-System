import { Banknote, DollarSign, WalletCards } from 'lucide-react'
import type { PayrollCycle, PayrollStatus } from '@hr/shared'
import { Badge, type BadgeTone } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { DataTable } from '@/components/ui/DataTable'
import type { TKey } from '@/features/i18n/dictionary'
import { useI18n } from '@/features/i18n/useI18n'
import { useLiveQuery } from '@/features/realtime/useLiveQuery'
import { api } from '@/lib/api'
import { errorKey } from '@/lib/apiError'

/**
 * Payroll status is rendered from the stored key, never from the text on screen,
 * so a language switch cannot change what a row means. `onHold` has no dictionary
 * entry of its own yet and reads as the nearest existing one.
 */
const statusMeta: Record<PayrollStatus, { label: TKey; tone: BadgeTone }> = {
  processed: { label: 'status.processed', tone: 'success' },
  underReview: { label: 'status.underReview', tone: 'warning' },
  onHold: { label: 'status.pending', tone: 'warning' },
}

export function HrPayrollPage() {
  const { t, loc, fmt } = useI18n()

  const payroll = useLiveQuery<PayrollCycle>(() => api.get('/payroll/cycle'), [], {
    on: ['employee.changed'],
  })

  const cycle = payroll.data
  const rows = cycle?.rows ?? []

  /**
   * A figure is shown only once the cycle has actually arrived: the currency
   * belongs to the payload, so there is nothing honest to render before it.
   */
  const figure = (pick: (c: PayrollCycle) => number) => {
    if (cycle) return fmt.money(pick(cycle), cycle.currency)
    return payroll.loading ? t('common.loading') : t('common.dash')
  }

  const figureClass = cycle ? 'text-3xl font-bold' : 'text-lg font-medium text-muted'

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium uppercase tracking-[0.18em] text-brand">{t('section.hr')}</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight">{t('hrPay.title')}</h2>
        </div>
        <div className="rounded-full bg-brand-50 px-3 py-1.5 text-sm font-medium text-brand">
          {figure((c) => c.netTotal)}
        </div>
      </div>

      {payroll.error && (
        <p role="alert" className="rounded-xl border border-danger/20 bg-red-50 px-3 py-2 text-sm text-danger">
          {t(errorKey(payroll.error))}
        </p>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <Card title={t('hrPay.net')} icon={Banknote} className="rounded-2xl">
          <p className={figureClass}>{figure((c) => c.netTotal)}</p>
          <p className="mt-2 text-sm text-muted">{t('hrPay.netSub')}</p>
        </Card>
        <Card title={t('hrPay.benefits')} icon={WalletCards} className="rounded-2xl">
          <p className={figureClass}>{figure((c) => c.allowancesTotal)}</p>
          <p className="mt-2 text-sm text-muted">{t('hrPay.benefitsSub')}</p>
        </Card>
        <Card title={t('hrPay.tax')} icon={DollarSign} className="rounded-2xl">
          <p className={figureClass}>{figure((c) => c.deductionsTotal)}</p>
          <p className="mt-2 text-sm text-muted">{t('hrPay.taxSub')}</p>
        </Card>
      </div>

      <Card title={t('hrPay.summary')} icon={Banknote} className="rounded-2xl">
        <DataTable
          rows={rows}
          /* A person appears once per cycle, so the payday pins the row even as the list reorders. */
          rowKey={(row) => `${row.userId}-${row.paidOn ?? 'unpaid'}`}
          loading={payroll.loading}
          empty={t('common.noData')}
          columns={[
            {
              key: 'employee',
              header: t('table.employee'),
              primary: true,
              cell: (row) => (
                <>
                  <p className="font-medium text-ink">{loc(row.employeeName)}</p>
                  <p className="text-xs font-normal text-muted">{row.employeeNumber}</p>
                </>
              ),
            },
            {
              key: 'amount',
              header: t('table.amount'),
              cell: (row) => <span className="text-muted">{fmt.money(row.netPay, row.currency)}</span>,
            },
            {
              key: 'status',
              header: t('table.status'),
              cell: (row) => {
                const meta = statusMeta[row.status]
                return <Badge tone={meta.tone}>{t(meta.label)}</Badge>
              },
            },
          ]}
        />
      </Card>
    </div>
  )
}
