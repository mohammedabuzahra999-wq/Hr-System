import type { GuidePage } from '@hr/shared'

/**
 * Every screen in the system, described.
 *
 * Written by hand against the router and the navigation config rather than
 * generated from them, because a route tells you a path exists and says nothing
 * about what somebody is meant to do there — which is the only part a person
 * asking for help actually needs.
 *
 * The cost of that choice is that this file has to be updated when a screen
 * changes. That cost is the point: a guide that quietly drifts out of date is
 * worse than none, because a user who is misdirected assumes they have
 * misunderstood, not that the software is wrong.
 */

const L = (en: string, ar: string) => ({ en, ar })

export const GUIDE_PAGES: GuidePage[] = [
  /* ---------- everyone, and the first thing they see ---------- */
  {
    path: '/assistant',
    roles: ['employee', 'manager', 'hr', 'admin'],
    title: L('MenaChat', 'مينا شات'),
    purpose: L(
      'Where every session starts. Ask it a question about this system in plain words, or tell it what to do and it does it — within whatever your role allows, and never beyond.',
      'من هون بتبلّش كل مرة. اسأله عن النظام بكلامك العادي، أو قلّه شو بدك يعمل وبيعمله — بحدود دورك، وما بيتجاوزها أبداً.',
    ),
    actions: [
      L('Ask: "how much leave do I have", "who is in today".', 'اسأل: «كم رصيد إجازاتي»، «مين حاضر اليوم».'),
      L('Instruct: "check me in", "submit leave for me". It shows you what it will do first.', 'اطلب: «سجّل حضوري»، «بدي إجازة». بيوريك شو رح يعمل قبل ما يعمله.'),
      L('Skip it any time — your screens are all in the menu.', 'تخطّاه أي وقت — شاشاتك كلها بالقائمة.'),
    ],
  },

  /* ---------- employee ---------- */
  {
    path: '/home',
    roles: ['employee'],
    title: L('My page', 'صفحتي'),
    purpose: L(
      'Everything about your own work: your attendance today, your leave balance, your requests, your payslips and your documents.',
      'كل شي يخصّك: حضورك اليوم، رصيد إجازاتك، طلباتك، كشوف رواتبك ومستنداتك.',
    ),
    actions: [
      L('Check in at the start of your day and check out at the end.', 'سجّل حضورك أول الدوام ومغادرتك بآخره.'),
      L('Request leave, and see whether your manager has decided.', 'اطلب إجازة، وشوف إذا مديرك قرّر.'),
      L('Ask for a salary certificate.', 'اطلب شهادة راتب.'),
      L('Open your payslips and your documents.', 'افتح كشوف رواتبك ومستنداتك.'),
    ],
  },

  /* ---------- manager ---------- */
  {
    path: '/manager',
    roles: ['manager'],
    title: L('Manager dashboard', 'لوحة المدير'),
    purpose: L(
      'Your team at a glance: who is in today, what is waiting for your decision, and your own attendance.',
      'فريقك بلمحة: مين حاضر اليوم، شو مستنّي قرارك، وحضورك إنت.',
    ),
    actions: [
      L('Check in and out yourself — managers record attendance too.', 'سجّل حضورك ومغادرتك — المدير كمان بيسجّل.'),
      L('See how many approvals are waiting.', 'شوف كم موافقة مستنّية.'),
    ],
  },
  {
    path: '/manager/team',
    roles: ['manager'],
    title: L('My team', 'فريقي'),
    purpose: L('The people who report to you, with their job titles and whether they are in the system now.', 'الموظفون الي بيرفعولك، بمسمّياتهم وهل هم موجودين بالنظام هلق.'),
    actions: [L('Open a team member to see their details.', 'افتح أي عضو بالفريق لتشوف تفاصيله.')],
  },
  {
    path: '/manager/attendance',
    roles: ['manager'],
    title: L('Team attendance', 'حضور الفريق'),
    purpose: L('Who was present, late or absent across your team, day by day.', 'مين حضر أو تأخّر أو غاب من فريقك، يوم بيوم.'),
    actions: [L('Filter by status to see only absences or only lateness.', 'فلتر حسب الحالة لتشوف الغياب بس أو التأخير بس.')],
  },
  {
    path: '/manager/leaves',
    roles: ['manager'],
    title: L('Leave management', 'إدارة الإجازات'),
    purpose: L('Leave taken and planned across your team, and their remaining balances.', 'الإجازات المأخوذة والمخطّطة بفريقك، وأرصدتهم المتبقّية.'),
    actions: [L('See who is away and when.', 'شوف مين مجاز وإمتى.')],
  },
  {
    path: '/manager/approvals',
    roles: ['manager'],
    title: L('Approvals', 'الموافقات'),
    purpose: L(
      'Requests from your team waiting on you. Leave is decided here, by you — not by HR and not by an administrator.',
      'طلبات فريقك المستنّية قرارك. الإجازة بتتقرّر هون، منّك إنت — مش من الموارد البشرية ولا الأدمن.',
    ),
    actions: [
      L('Approve or reject a leave request, with a reason.', 'وافق أو ارفض طلب إجازة، مع سبب.'),
      L('See whether the person is in the system right now before deciding.', 'شوف إذا الشخص موجود بالنظام هلق قبل ما تقرّر.'),
    ],
  },
  {
    path: '/manager/calendar',
    roles: ['manager'],
    title: L('Team calendar', 'تقويم الفريق'),
    purpose: L('Leave, holidays and meetings laid out by date.', 'الإجازات والعطل والاجتماعات مرتّبة بالتواريخ.'),
    actions: [L('See overlapping absences before approving more.', 'شوف الغيابات المتداخلة قبل ما توافق على غيرها.')],
  },
  {
    path: '/manager/reports',
    roles: ['manager'],
    title: L('Team reports', 'تقارير الفريق'),
    purpose: L('Attendance and leave figures for your team over a period.', 'أرقام الحضور والإجازات لفريقك عبر فترة.'),
    actions: [L('Ask the assistant for a team report in plain words.', 'اطلب من المساعد تقرير فريق بكلامك العادي.')],
  },
  {
    path: '/manager/announcements',
    roles: ['manager'],
    title: L('Announcements', 'الإعلانات'),
    purpose: L('Notices you post, which everyone in the company sees with your name on them.', 'إعلانات بتنشرها، وبتوصل كل الشركة باسمك عليها.'),
    actions: [
      L('Post a notice, a holiday or a meeting.', 'انشر إعلان أو عطلة أو اجتماع.'),
      L('Set how long it stays up, and edit or withdraw it later.', 'حدّد كم بيضل منشور، وعدّله أو اسحبه بعدين.'),
    ],
  },

  /* ---------- HR ---------- */
  {
    path: '/hr',
    roles: ['hr'],
    title: L('HR centre', 'مركز الموارد البشرية'),
    purpose: L('The overview: headcount, attendance today, leave awaiting review, and your own attendance.', 'النظرة العامة: عدد الموظفين، حضور اليوم، الإجازات بانتظار المراجعة، وحضورك إنت.'),
    actions: [L('Check in and out yourself.', 'سجّل حضورك ومغادرتك.')],
  },
  {
    path: '/hr/employees',
    roles: ['hr'],
    title: L('Employee records', 'سجلات الموظفين'),
    purpose: L(
      'The staff directory, and a lookup that opens one person’s whole file from their employee number.',
      'دليل الموظفين، واستعلام بيفتح ملف الشخص كامل من رقمه الوظيفي.',
    ),
    actions: [
      L('Type an employee number to see their attendance, leave, salary, documents and requests in one place.', 'اكتب الرقم الوظيفي لتشوف حضوره وإجازاته وراتبه ومستنداته وطلباته بمكان واحد.'),
      L('Add an employee, or change their role.', 'أضف موظّف، أو غيّر دوره.'),
    ],
  },
  {
    path: '/hr/attendance',
    roles: ['hr'],
    title: L('Attendance overview', 'نظرة على الحضور'),
    purpose: L('Attendance across the whole company, not one team.', 'الحضور على مستوى الشركة كاملة، مش فريق واحد.'),
    actions: [L('Remind people who have not checked out.', 'ذكّر الي ما سجّلوا مغادرة.')],
  },
  {
    path: '/hr/leaves',
    roles: ['hr'],
    title: L('Leaves', 'الإجازات'),
    purpose: L(
      'Every leave request in the company, and where each one stands. HR sees these; the employee’s own manager decides them.',
      'كل طلبات الإجازات بالشركة ووين وصل كل واحد. الموارد البشرية بتشوفهم؛ ومدير الموظّف هو الي بيقرّر.',
    ),
    actions: [L('Track a request, and see who decided it and when.', 'تتبّع طلب، وشوف مين قرّره وإمتى.')],
  },
  {
    path: '/hr/recruitment',
    roles: ['hr'],
    title: L('Recruitment', 'التوظيف'),
    purpose: L(
      'Vacancies, the applications that arrive against them, and the text to post on LinkedIn.',
      'الوظائف الشاغرة، والطلبات الي بتوصل عليها، ونصّ المنشور للينكدإن.',
    ),
    actions: [
      L('Create a vacancy, edit it, and publish it to the public careers page.', 'أنشئ وظيفة، عدّلها، وانشرها على صفحة الوظائف العامة.'),
      L('Copy the public link, or the ready-made LinkedIn post.', 'انسخ الرابط العام، أو منشور لينكدإن الجاهز.'),
      L('Read applications, see the CV match, and move a candidate along.', 'اقرأ الطلبات، شوف نسبة تطابق السيرة، وحرّك المرشّح.'),
    ],
  },
  {
    path: '/hr/job-descriptions',
    roles: ['hr'],
    title: L('Job descriptions', 'الأوصاف الوظيفية'),
    purpose: L(
      'Write a job description with AI from the requirements you type, review it, and approve it.',
      'اكتب وصف وظيفي بالذكاء الاصطناعي من المتطلبات الي بتكتبها، راجعه، واعتمده.',
    ),
    actions: [
      L('Enter the role and its requirements, then generate.', 'اكتب المسمّى ومتطلباته، وبعدين ولّد.'),
      L('Edit any section by hand, or regenerate just that section.', 'عدّل أي قسم بإيدك، أو أعد توليد هاد القسم لحاله.'),
      L('Approve it — which also creates a draft vacancy on the recruitment page.', 'اعتمده — وهاد كمان بينشئ وظيفة مسودّة بصفحة التوظيف.'),
    ],
  },
  {
    path: '/hr/announcements',
    roles: ['hr'],
    title: L('Announcements', 'الإعلانات'),
    purpose: L('Notices to the whole company: holidays, meetings, policy changes.', 'إعلانات لكل الشركة: عطل، اجتماعات، تغييرات بالسياسات.'),
    actions: [L('Post, edit, or withdraw a notice, and set how long it stays up.', 'انشر أو عدّل أو اسحب إعلان، وحدّد كم بيضل منشور.')],
  },
  {
    path: '/hr/payroll',
    roles: ['hr'],
    title: L('Payroll', 'الرواتب'),
    purpose: L('Salaries, payslips and the monthly payroll cycle.', 'الرواتب وكشوف الرواتب ودورة الرواتب الشهرية.'),
    actions: [L('See the current cycle and what each person is paid.', 'شوف الدورة الحالية وكم بيتقاضى كل شخص.')],
  },
  {
    path: '/hr/reports',
    roles: ['hr'],
    title: L('Reports', 'التقارير'),
    purpose: L('Figures across the company — attendance, leave, headcount, recruitment.', 'أرقام على مستوى الشركة — حضور، إجازات، عدد موظفين، توظيف.'),
    actions: [L('Ask the assistant for a report in plain words and print it.', 'اطلب من المساعد تقرير بكلامك العادي واطبعه.')],
  },

  /* ---------- admin ---------- */
  {
    path: '/dashboard',
    roles: ['admin'],
    title: L('Dashboard', 'لوحة المعلومات'),
    purpose: L('System-wide figures and activity.', 'أرقام ونشاط على مستوى النظام.'),
    actions: [],
  },
  {
    path: '/admin',
    roles: ['admin'],
    title: L('Admin overview', 'نظرة عامة على الإدارة'),
    purpose: L('The state of the system: accounts, roles, attendance and alerts worth looking at.', 'حالة النظام: الحسابات، الأدوار، الحضور، والتنبيهات الي تستاهل نظرة.'),
    actions: [L('Check in and out yourself.', 'سجّل حضورك ومغادرتك.')],
  },
  {
    path: '/admin/users',
    roles: ['admin'],
    title: L('User roles', 'أدوار المستخدمين'),
    purpose: L('Who has which role, and whether their account is active.', 'مين عنده أي دور، وهل حسابه مفعّل.'),
    actions: [
      L('Change somebody’s role, or disable their account.', 'غيّر دور حدا، أو عطّل حسابه.'),
      L('Reset a password — you cannot read an existing one, only replace it.', 'صفّر كلمة سر — ما بتقدر تقرأ الموجودة، بس تستبدلها.'),
    ],
  },
  {
    path: '/admin/approvals',
    roles: ['admin'],
    title: L('Approvals', 'الموافقات'),
    purpose: L(
      'Every request in the company, for oversight. Decisions are made by each employee’s own manager, not here.',
      'كل الطلبات بالشركة، للاطّلاع. القرارات بياخدها مدير كل موظّف، مش من هون.',
    ),
    actions: [L('See what is pending and who it is waiting on.', 'شوف شو معلّق ومستنّي مين.')],
  },
  {
    path: '/admin/announcements',
    roles: ['admin'],
    title: L('Announcements', 'الإعلانات'),
    purpose: L('Notices from the administrator to everyone, and oversight of anyone else’s.', 'إعلانات من مدير النظام للكل، ومتابعة إعلانات غيره.'),
    actions: [L('Post a notice, or edit and withdraw one posted by HR or a manager.', 'انشر إعلان، أو عدّل واسحب إعلان نشرته الموارد البشرية أو مدير.')],
  },

  {
    path: '/manager/profile',
    roles: ['manager'],
    title: L('My profile', 'ملفي الشخصي'),
    purpose: L(
      'Your own record as HR holds it, and your own working day — a manager is an employee too.',
      'ملفك زي ما الموارد البشرية شايفته، ودوامك أنت — المدير موظف كمان.',
    ),
    actions: [
      L('Check your own attendance and request your own leave here.', 'سجّل حضورك واطلب إجازتك من هون.'),
    ],
  },

  /* ---------- everyone ---------- */
  {
    path: '/careers',
    roles: ['admin', 'manager', 'hr', 'employee'],
    title: L('Careers page', 'صفحة الوظائف'),
    purpose: L(
      'The public page. Anybody on the internet can open it with no account and apply — this is where applications come from.',
      'الصفحة العامة. أي حدا على الإنترنت بيفتحها بلا حساب ويقدّم — من هون بتيجي الطلبات.',
    ),
    actions: [L('Open it to see a vacancy the way a candidate sees it.', 'افتحها لتشوف الوظيفة زي ما بيشوفها المرشّح.')],
  },
]

/** The page entry for a route, matched longest-first so `/hr/leaves` beats `/hr`. */
export function pageFor(path: string | undefined, role: string): GuidePage | null {
  if (!path) return null
  const clean = path.split('?')[0]!.split('#')[0]!
  const candidates = GUIDE_PAGES.filter(
    (p) => p.roles.includes(role as GuidePage['roles'][number]) && clean.startsWith(p.path),
  )
  return candidates.sort((a, b) => b.path.length - a.path.length)[0] ?? null
}
