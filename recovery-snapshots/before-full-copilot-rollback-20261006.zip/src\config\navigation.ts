import {
  BriefcaseBusiness,
  FileText,
  House,
  LayoutDashboard,
  Bell,
  Bot,
  CalendarDays,
  Clock3,
  ReceiptText,
  Settings,
  UserRound,
  UsersRound,
  type LucideIcon,
} from 'lucide-react'
import type { Role } from '@/lib/roles'
import type { TKey } from '@/features/i18n/dictionary'

export interface NavItem {
  label: string
  labelKey?: TKey
  to: string
  hash?: string
  icon: LucideIcon
  roles: Role[]
}

/** Sidebar links by role. */
export const navItems: NavItem[] = [
  { label: 'MenaChat', labelKey: 'assistant.name', to: '/assistant', icon: Bot, roles: ['admin', 'manager', 'hr', 'employee'] },
  { label: 'Dashboard', labelKey: 'nav.dashboard', to: '/dashboard', icon: LayoutDashboard, roles: ['admin'] },
  { label: 'Admin Overview', labelKey: 'nav.adminOverview', to: '/admin', icon: LayoutDashboard, roles: ['admin'] },
  { label: 'User Roles', labelKey: 'nav.userRoles', to: '/admin/users', icon: UsersRound, roles: ['admin'] },
  { label: 'Approvals', labelKey: 'nav.approvals', to: '/admin/approvals', icon: FileText, roles: ['admin'] },
  { label: 'Announcements', labelKey: 'nav.announcements', to: '/admin/announcements', icon: Bell, roles: ['admin'] },
  { label: 'Permissions', labelKey: 'nav.permissions', to: '/admin/permissions', icon: Settings, roles: ['admin'] },
  { label: 'Dashboard', labelKey: 'nav.dashboard', to: '/manager', icon: LayoutDashboard, roles: ['manager'] },
  { label: 'My Team', labelKey: 'nav.myTeam', to: '/manager/team', icon: UsersRound, roles: ['manager'] },
  { label: 'Team Attendance', labelKey: 'nav.teamAttendance', to: '/manager/attendance', icon: Clock3, roles: ['manager'] },
  { label: 'Leave Management', labelKey: 'nav.leaveManagement', to: '/manager/leaves', icon: CalendarDays, roles: ['manager'] },
  { label: 'Approvals', labelKey: 'nav.approvals', to: '/manager/approvals', icon: FileText, roles: ['manager'] },
  { label: 'Team Calendar', labelKey: 'nav.teamCalendar', to: '/manager/calendar', icon: CalendarDays, roles: ['manager'] },
  { label: 'Team Reports', labelKey: 'nav.teamReports', to: '/manager/reports', icon: ReceiptText, roles: ['manager'] },
  { label: 'Announcements', labelKey: 'nav.announcements', to: '/manager/announcements', icon: Bell, roles: ['manager'] },
  { label: 'My Profile', labelKey: 'nav.myProfile', to: '/manager/profile', icon: UserRound, roles: ['manager'] },
  { label: 'HR center', labelKey: 'nav.hrCenter', to: '/hr', icon: BriefcaseBusiness, roles: ['hr'] },
  { label: 'Employees', labelKey: 'nav.employees', to: '/hr/employees', icon: UsersRound, roles: ['hr'] },
  { label: 'Attendance', labelKey: 'nav.attendance', to: '/hr/attendance', icon: Clock3, roles: ['hr'] },
  { label: 'Leaves', labelKey: 'nav.leaves', to: '/hr/leaves', icon: CalendarDays, roles: ['hr'] },
  { label: 'Payroll', labelKey: 'nav.payroll', to: '/hr/payroll', icon: ReceiptText, roles: ['hr'] },
  { label: 'Reports', labelKey: 'nav.reports', to: '/hr/reports', icon: ReceiptText, roles: ['hr'] },
  { label: 'Recruitment', labelKey: 'nav.recruitment', to: '/hr/recruitment', icon: BriefcaseBusiness, roles: ['hr'] },
  { label: 'Job descriptions', labelKey: 'nav.jobDescriptions', to: '/hr/job-descriptions', icon: FileText, roles: ['hr'] },
  { label: 'Announcements', labelKey: 'nav.announcements', to: '/hr/announcements', icon: Bell, roles: ['hr'] },
  { label: 'Overview', labelKey: 'nav.home', to: '/home', hash: 'overview', icon: House, roles: ['employee'] },
  { label: 'Attendance', labelKey: 'nav.attendance', to: '/home', hash: 'attendance', icon: Clock3, roles: ['employee'] },
  { label: 'Leaves', labelKey: 'nav.leaves', to: '/home', hash: 'leave', icon: CalendarDays, roles: ['employee'] },
  { label: 'Requests', labelKey: 'nav.reports', to: '/home', hash: 'requests', icon: FileText, roles: ['employee'] },
  { label: 'Payslips', labelKey: 'nav.payroll', to: '/home', hash: 'payslips', icon: ReceiptText, roles: ['employee'] },
  { label: 'Notifications', labelKey: 'nav.announcements', to: '/home', hash: 'notifications', icon: Bell, roles: ['employee'] },
]
