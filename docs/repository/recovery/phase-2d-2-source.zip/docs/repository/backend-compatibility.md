# Backend compatibility preparation (Phase 2D-1)

The backend remains at `server/`, with package identity `@hr/server`. Contracts
remain `@hr/shared` at `packages/contracts`. No source package has moved in this
phase. The pre-edit SHA-256 inventory is [phase-2d-1-before.json](baselines/phase-2d-1-before.json).
It excludes environment files, private uploads, local properties, browser state,
logs, dependency installations and generated output. It is not a backup.

## Current and future paths

`server/scripts/repositoryPaths.mjs` calculates paths for the current `server`
package or the future `services/hr-api` package, anchored at maintained workspace
markers. It rejects other backend locations. The asset-copy, voice setup and
voice launcher scripts consume this helper. Their current destinations remain
the same. The asset-copy script has a read-only `--dry-run`; normal build-copy
behavior is unchanged, including replacement of generated migration output.

| Item | Current | Prepared future |
|---|---|---|
| Compiler root | Repository root | Repository root |
| Emitted API package | `server/dist/server` | `services/hr-api/dist/services/hr-api` |
| Production entry, package-relative | `dist/server/src/index.js` | `dist/services/hr-api/src/index.js` |
| Emitted contracts | `dist/packages/contracts/src` | Same relative to API package |
| Runtime JSONL | Emitted package `src/copilot/data/` | Same relative to emitted package |
| Copied SQL/metadata | Emitted package `drizzle/` | Same relative to emitted package |
| Migration runner | `../../drizzle` from emitted `src/db` | Unchanged |
| Python worker | `server/local-voice/worker.py` | Retained at the same location |
| Voice installation/token | Repository `.local-voice/` | Retained at the same location |

## Environment and uploads: passive preparation

`runtimePreload.mjs` is prepared as a future opt-in Node preload. **No current
package command invokes it.** It calls the initializer before application modules
are loaded. Do not import it during offline checks or run it against real runtime
configuration during migration validation.

When explicitly activated in a later approved phase, initialization will:

- Select retained `server/.env`, or an explicit `DOTENV_CONFIG_PATH` resolved
  against the caller's working directory.
- Ask dotenv to populate only absent variables, preserving inherited values;
  suppress dotenv logging/debug output and honor the configured encoding.
- Keep later `dotenv/config` imports on the same selected environment file.
- Anchor relative `UPLOAD_DIR` values at retained `server/`; absolute paths stay
  absolute. The default remains `server/uploads`.
- Allow deployments that supply their full environment without a file; report
  other load errors with a generic message that includes no file contents.

No secret values are stored in source, returned by the initializer or logged.
Phase 2D-1 validation injects synthetic environment objects and loaders. It never
calls the actual dotenv file loader. Existing startup behavior is unchanged;
environment compatibility is prepared, not activated or verified against secrets.

## Explicit wording-check compatibility fix

The web package's wording check previously resolved `../server` to nonexistent
`apps/server`. Its single filesystem reference now reads `../../server` from the
web workspace. No dictionary, intent, assertion or application logic changes.
This check will need the separately approved `../../services/hr-api` path during
the eventual API relocation.

## Offline validation and remaining relocation work

Run only the pure `node server/scripts/compatibility.check.mjs`, script syntax
checks, workspace type/lint checks and the frontend wording check for this stage.
The compatibility check calculates future compiler output names without emitting
files, tests environment/upload behavior with synthetic data, and exercises only
the asset-copy dry run. It does not import API/MCP/worker entry points.

Before relocation, review and approve:

1. Workspace/lockfile edits and a selective move excluding `.env`, uploads,
   worker, runtime state, old output and historical results.
2. The relocated TypeScript `rootDir: ../..`, contracts include path and start
   target. The current active TypeScript configuration remains unchanged.
3. Preload wiring for every environment-dependent entry point, preserving dev
   watch behavior and process-environment precedence. Pure checks use synthetic
   configuration; do not initialize them from the real environment.
4. Backend worker-token repository detection, cross-package frontend paths and
   current documentation. These Phase 2D-2 edits are not performed here.
5. Fresh emitted-output inspection with an explicitly approved build; do not
   execute migrations or start services as a shortcut.

SQL migrations/metadata, runtime JSONL, private data and historical evidence are
immutable in this stage. Do not run the API, MCP, voice launcher/setup, migration,
seed, embedding, CV import, model, benchmark, deployment or training commands.
The pre-existing guide/tour coverage debt remains recorded and unrepaired.
