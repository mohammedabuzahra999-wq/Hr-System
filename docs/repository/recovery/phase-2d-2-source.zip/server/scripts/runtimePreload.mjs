import { fileURLToPath } from 'node:url'
import { prepareRetainedRuntime } from './repositoryPaths.mjs'

// Prepared for an explicitly approved future --import invocation. No current
// package command loads this module. Do not import it during offline validation.
prepareRetainedRuntime({ backendRoot: fileURLToPath(new URL('../', import.meta.url)) })
